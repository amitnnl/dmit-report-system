<?php
// Start output buffering at the very beginning
ob_start();

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Include configuration files
require 'config/db.php';

// Handle Login
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $query = "SELECT * FROM users WHERE username=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $stmt->close();
            ob_end_clean(); // Clean output buffer before redirect
            header("Location: dashboard.php");
            exit;
        } else {
            $error = "Invalid password!";
        }
    } else {
        $error = "User not found!";
    }
    $stmt->close();
}

// Include header after all potential header operations
include 'includes/header.php';

// Handle Fingerprint Input
if (isset($_POST['submit_data'])) {
    if (!isset($_SESSION['user_id'])) {
        die("Unauthorized access");
    }

    $user_id = $_SESSION['user_id'];
    $name = trim($_POST['name']);
    $gender = trim($_POST['gender']);
    $age = (int)$_POST['age'];
    $contact = (int)$_POST['contact'];
    $city = trim($_POST['city']);

    $L = array_map('floatval', [$_POST['L1'], $_POST['L2'], $_POST['L3'], $_POST['L4'], $_POST['L5']]);
    $R = array_map('floatval', [$_POST['R1'], $_POST['R2'], $_POST['R3'], $_POST['R4'], $_POST['R5']]);

    $total_left = array_sum($L);
    $total_right = array_sum($R);
    $total = $total_left + $total_right;

    $query = "INSERT INTO fingerprint_data 
        (user_id, name, gender, age, contact, city, L1, L2, L3, L4, L5, R1, R2, R3, R4, R5, total_left, total_right, total) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("ississddddddddddddd",
        $user_id, $name, $gender, $age, $contact, $city,
        $L[0], $L[1], $L[2], $L[3], $L[4],
        $R[0], $R[1], $R[2], $R[3], $R[4],
        $total_left, $total_right, $total
    );

    if ($stmt->execute()) {
        $conn->commit();
        $stmt->close();
        ob_end_clean(); // Clean output buffer before redirect
        include 'calculate_data.php';
        header("Location: report.php");
        exit;
    } else {
        die("Error storing data: " . $conn->error);
    }
}

// Display HTML content
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dermatoglyphics Multiple Intelligence Test</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/main.css?v=<?= time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- Your Custom JS Files -->
    <script src="assets/js/main.js?v=<?= time(); ?>"></script>
</head>
<body>
<div class="container">
    
        <?php if (!isset($_SESSION['user_id'])): ?>
            <!-- LOGIN PAGE -->
            <div class="login-container card login-grid">
                <!-- Left: Form -->
                <div class="login-left">
                    <h2>Welcome Back</h2>
                    <?php if (isset($error)): ?>
                        <div class="error-msg"><?= $error ?></div>
                    <?php endif; ?>

                    <form method="POST" class="login-form">
                        <div class="floating-input-group">
                            <input type="text" name="username" id="username" placeholder=" " required>
                            <label for="username"><i class="fa-solid fa-user"></i> Username</label>
                        </div>

                        <div class="floating-input-group">
                            <input type="password" name="password" id="password" placeholder=" " required>
                            <label for="password"><i class="fa-solid fa-lock"></i> Password</label>
                        </div>

                        <div class="form-buttons">
                            <button type="submit" name="login" class="btn btn-primary">
                                <i class="fa-solid fa-right-to-bracket"></i> Login
                            </button>
                            <a href="pages/reset_password.php" class="btn btn-outline">
                                <i class="fa-solid fa-unlock-keyhole"></i> Forgot Password?
                            </a>
                        </div>
                    </form>
                </div>

                <!-- Right: Logo -->
                <div class="login-right">
                    <img src="uploads/logo.png" class="logo-img" alt="Logo">
                    <h3>We analyze your fingerprints and generate career intelligence reports.</h3>
                </div>
            </div>
        <?php else: ?>
		
            <!-- DATA ENTRY PAGE -->
			
<div class="container">
    <div class="form-card">
        <h2 style="text-align: center;">Personal & Fingerprint Details</h2>
		<form method="POST" action="" class="form-grid" id="fingerprintForm">

            <!-- Personal Info Column -->
            <div class="form-section personal-info-column">
                <h3>Personal Information</h3>
                <div class="floating-input-group">
                    <input type="text" name="name" id="name" placeholder=" " required>
                    <label for="name">Full Name</label>
                </div>
                <div class="floating-input-group">
                    <select name="gender" id="gender" required>
                        <option value="" hidden selected disabled></option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                    <label for="gender">Gender</label>
                </div>
                <div class="floating-input-group">
                    <input type="number" name="age" id="age" placeholder=" " min="1" max="100" required>
                    <label for="age">Age</label>
                </div>
                <div class="floating-input-group">
                    <input type="text" name="city" id="city" placeholder=" " required>
                    <label for="city">City</label>
                </div>
                <div class="floating-input-group">
                    <input type="tel" name="contact" id="contact" pattern="[0-9]{10,11}" maxlength="11" placeholder=" " required>
                    <label for="contact">Contact</label>
                </div>
            </div>

            <!-- Left Hand Column -->
            <div class="form-section left-hand-column">
                <h3>Left Hand</h3>
                <?php foreach (['L1','L2','L3','L4','L5'] as $field): ?>
                    <div class="floating-input-group">
                        <input type="number" name="<?= $field ?>" id="<?= $field ?>" step="0.01" min="0" max="100" placeholder=" " required>
                        <label for="<?= $field ?>"><?= $field ?> (0–100)</label>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Right Hand Column -->
            <div class="form-section right-hand-column">
                <h3>Right Hand</h3>
                <?php foreach (['R1','R2','R3','R4','R5'] as $field): ?>
                    <div class="floating-input-group">
                        <input type="number" name="<?= $field ?>" id="<?= $field ?>" step="0.01" min="0" max="100" placeholder=" " required>
                        <label for="<?= $field ?>"><?= $field ?> (0–100)</label>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Buttons (spans all columns) -->
            <div class="form-buttons">
                <button type="reset" class="btn btn-outline">Clear</button>
                <button type="submit" name="submit_data" class="btn btn-primary">Submit</button>
            </div>
        </form>
    </div>
</div>
            <script>
                // Realtime Validation
                document.querySelectorAll('.validated-input').forEach(input => {
                    input.addEventListener('input', () => {
                        const value = parseFloat(input.value);
                        if (value < 0 || value > 100 || isNaN(value)) {
                            input.classList.add('invalid');
                            input.setCustomValidity("Enter a value between 0 and 100.");
                        } else {
                            input.classList.remove('invalid');
                            input.setCustomValidity("");
                        }
                    });
                });
            </script>
        <?php endif; ?>
    
</div>
<?php include 'includes/footer.php'; ?>
</body>
</html>
<?php
// Flush the output buffer at the end
ob_end_flush();
?>