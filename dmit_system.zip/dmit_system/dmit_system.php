<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    die("Error: User not logged in.");
}

$user_id = $_SESSION['user_id'];

// Get latest fingerprint data
$query = "SELECT * FROM fingerprint_data WHERE user_id = ? ORDER BY id DESC LIMIT 1";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();
$stmt->close();

if (!$data) {
    die("Error: No fingerprint data found.");
}

// Begin transaction
$conn->begin_transaction();

try {
    // Calculate total fingerprint counts
    $total = $data['L1'] + $data['L2'] + $data['L3'] + $data['L4'] + $data['L5']
           + $data['R1'] + $data['R2'] + $data['R3'] + $data['R4'] + $data['R5'];

    // Brain region calculations
    $prefrontal = (($data['L1'] + $data['R1']) / $total) * 100;
    $frontal    = (($data['L2'] + $data['R2']) / $total) * 100;
    $parietal   = (($data['L3'] + $data['R3']) / $total) * 100;
    $temporal   = (($data['L4'] + $data['R4']) / $total) * 100;
    $occipital  = (($data['L5'] + $data['R5']) / $total) * 100;

    // Intelligence type calculations
    $intrapersonal = $data['R1'];
    $interpersonal = $data['L1'];
    $visual        = $data['L2'];
    $logical       = $data['R2'];
    $kinesthetic   = ($data['L3'] + $data['R3']) / 2;
    $musical       = $data['L4'];
    $linguistic    = $data['R4'];
    $naturalist    = $data['R5'];

    // Quotient calculations
    $EQ  = $intrapersonal + $interpersonal;
    $AQ  = $kinesthetic + $naturalist;
    $IQ  = $linguistic + $logical;
    $CQ  = $visual + $musical;
    $total_quotient = $EQ + $AQ + $IQ + $CQ;
    
    $MOT = ($data['R1'] + $data['R2'] + $data['R3'] + $data['R4'] + $data['R5']) / $total * 100;
    $REF = ($data['L1'] + $data['L2'] + $data['L3'] + $data['L4'] + $data['L5']) / $total * 100;

    // Store intelligence scores
    $stmt = $conn->prepare("INSERT INTO intelligence_scores 
        (user_id, prefrontal, frontal, parietal, temporal, occipital, 
        intrapersonal, interpersonal, visual, logical, kinesthetic, musical, linguistic, naturalist, 
        EQ, AQ, IQ, CQ, MOT, REF) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
        prefrontal = VALUES(prefrontal),
        frontal = VALUES(frontal),
        parietal = VALUES(parietal),
        temporal = VALUES(temporal),
        occipital = VALUES(occipital),
        intrapersonal = VALUES(intrapersonal),
        interpersonal = VALUES(interpersonal),
        visual = VALUES(visual),
        logical = VALUES(logical),
        kinesthetic = VALUES(kinesthetic),
        musical = VALUES(musical),
        linguistic = VALUES(linguistic),
        naturalist = VALUES(naturalist),
        EQ = VALUES(EQ),
        AQ = VALUES(AQ),
        IQ = VALUES(IQ),
        CQ = VALUES(CQ),
        MOT = VALUES(MOT),
        REF = VALUES(REF)");

    $stmt->bind_param("iddddddddddddddddddd", 
        $user_id, $prefrontal, $frontal, $parietal, $temporal, $occipital,
        $intrapersonal, $interpersonal, $visual, $logical, $kinesthetic, 
        $musical, $linguistic, $naturalist, $EQ, $AQ, $IQ, $CQ, $MOT, $REF);
    $stmt->execute();
    $stmt->close();

    // Calculate career scores
    $career_scores = [
        'information_tech' => $logical + $visual,
        'engineering' => $logical + $visual + $naturalist,
        'mathematical' => $logical + $visual,
        'medical' => $logical + $kinesthetic + $naturalist,
        'life_science' => $naturalist + $logical,
        'earth_environment' => $naturalist + $visual + $logical,
        'construction_design' => $visual + $logical,
        'artistry' => $kinesthetic + $musical + $visual,
        'sociology_psychology' => $intrapersonal + $interpersonal,
        'mass_communication' => $linguistic + $visual + $kinesthetic,
        'foreign_language' => $linguistic + $interpersonal,
        'literature_history_philosophy' => $linguistic + $intrapersonal,
        'education' => $linguistic + $interpersonal,
        'political_affair' => $linguistic + $logical + $interpersonal,
        'management' => $intrapersonal + $interpersonal + $linguistic,
        'financial' => $logical,
        'sports' => $kinesthetic,
        'occult' => $linguistic + $logical + $interpersonal
    ];

    // Store career rankings
    $columns = implode(", ", array_keys($career_scores));
    $placeholders = implode(", ", array_fill(0, count($career_scores), "?"));
    $insert_query = "INSERT INTO career_rankings (user_id, $columns) VALUES (?, $placeholders) 
                    ON DUPLICATE KEY UPDATE " . 
                    implode(", ", array_map(fn($key) => "$key = VALUES($key)", array_keys($career_scores)));

    $stmt = $conn->prepare($insert_query);
    $param_types = "i" . str_repeat("d", count($career_scores));
    $params = array_merge([$user_id], array_values($career_scores));
    $stmt->bind_param($param_types, ...$params);
    $stmt->execute();
    $stmt->close();

    // Commit transaction
    $conn->commit();

    // Redirect to report page
    header("Location: report.php");
    exit();

} catch (Exception $e) {
    $conn->rollback();
    die("Error processing data: " . $e->getMessage());
}
?>