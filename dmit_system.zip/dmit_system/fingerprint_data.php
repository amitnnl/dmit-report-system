<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include 'config/db.php';  // Include your database connection file

$user_id = $_SESSION['user_id'];  // Ensure user is logged in

$query = "SELECT * FROM fingerprint_data WHERE user_id = ? ORDER BY id DESC LIMIT 1";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$fingerprint = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="assets/css/main.css?v=<?php echo time(); ?>">
    <title>Fingerprint Data</title>
</head>
<body>
<?php if ($fingerprint): ?>
    <!-- Display User Info -->
    <div class="user-info">
        <h2>User Information</h2>
        <p><strong>Name:</strong> <?= htmlspecialchars($fingerprint['name']) ?></p>
        <p><strong>Gender:</strong> <?= htmlspecialchars($fingerprint['gender']) ?></p>
        <p><strong>Age:</strong> <?= intval($fingerprint['age']) ?></p>
		<p><strong>Contact:</strong> <?= intval($fingerprint['contact']) ?></p>
		<p><strong>City:</strong> <?= intval($fingerprint['city']) ?></p>
    </div>

    <div class="grid-container">
        <!-- Left Hand -->
        <div class="column left">
            <h3>Left Hand Fingerprint</h3>
            <table>
                <tr><th>Finger</th><th>Value</th></tr>
                <tr><td>L1</td><td><?= number_format($fingerprint['L1'], 2) ?></td></tr>
                <tr><td>L2</td><td><?= number_format($fingerprint['L2'], 2) ?></td></tr>
                <tr><td>L3</td><td><?= number_format($fingerprint['L3'], 2) ?></td></tr>
                <tr><td>L4</td><td><?= number_format($fingerprint['L4'], 2) ?></td></tr>
                <tr><td>L5</td><td><?= number_format($fingerprint['L5'], 2) ?></td></tr>
                <tr><th>Total Left</th><th><?= number_format($fingerprint['total_left'], 2) ?></th></tr>
            </table>
        </div>

        <!-- Right Hand -->
        <div class="column right">
            <h3>Right Hand Fingerprint</h3>
            <table>
                <tr><th>Finger</th><th>Value</th></tr>
                <tr><td>R1</td><td><?= number_format($fingerprint['R1'], 2) ?></td></tr>
                <tr><td>R2</td><td><?= number_format($fingerprint['R2'], 2) ?></td></tr>
                <tr><td>R3</td><td><?= number_format($fingerprint['R3'], 2) ?></td></tr>
                <tr><td>R4</td><td><?= number_format($fingerprint['R4'], 2) ?></td></tr>
                <tr><td>R5</td><td><?= number_format($fingerprint['R5'], 2) ?></td></tr>
                <tr><th>Total Right</th><th><?= number_format($fingerprint['total_right'], 2) ?></th></tr>
            </table>
        </div>
    </div>

    <!-- Overall Total spanning full width -->
    <div class="overall-total-full">
        <h4>Overall Total FingerPrint Counting Reas</h4>
        <p><strong><?= number_format($fingerprint['total'], 2) ?></strong></p>
    </div>
<?php else: ?>
    <p>No fingerprint data available.</p>
<?php endif; ?>

</body>
</html>
