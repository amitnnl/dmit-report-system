<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include 'config/db.php';
include 'includes/header.php';

$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Get the correct user ID from session
$current_user_id = $_SESSION['user_id'] ?? $_SESSION['id'] ?? 0;

// Modified query without created_at
$query = "SELECT id, user_id, name, gender, age, contact, city, total FROM fingerprint_data WHERE 1=1";
$params = [];
$types = '';

if (!empty($search)) {
    $query .= " AND (name LIKE ? OR gender LIKE ? OR contact LIKE ? OR city LIKE ?)";
    $search_term = "%$search%";
    $params = array_merge($params, [$search_term, $search_term, $search_term, $search_term]);
    $types .= 'ssss';
}

if (!$is_admin) {
    $query .= " AND user_id = ?";
    $params[] = $current_user_id;
    $types .= 'i';
}

$query .= " ORDER BY id DESC LIMIT ? OFFSET ?";  // Using id for sorting instead of created_at
$params = array_merge($params, [$per_page, $offset]);
$types .= 'ii';

$stmt = $conn->prepare($query);
if ($types) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$clients = $result->fetch_all(MYSQLI_ASSOC);

// COUNT QUERY
$count_query = "SELECT COUNT(*) as total FROM fingerprint_data WHERE 1=1";
if (!empty($search)) {
    $search_escaped = $conn->real_escape_string($search);
    $count_query .= " AND (name LIKE '%$search_escaped%' OR gender LIKE '%$search_escaped%' OR contact LIKE '%$search_escaped%' OR city LIKE '%$search_escaped%')";
}
if (!$is_admin) {
    $count_query .= " AND user_id = $current_user_id";
}
$count_result = $conn->query($count_query);
$total_clients = $count_result->fetch_assoc()['total'];
$total_pages = ceil($total_clients / $per_page);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Client List - DMIT Fingerprint Reports</title>
    <link rel="stylesheet" href="assets/css/main.css?v=<?= time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* ... (keep all your existing styles) ... */
    </style>
</head>
<body>
    <div class="client-list-container">
        <h2><i class="fas fa-fingerprint"></i> Fingerprint Test Clients</h2>
        
        <form method="get" class="search-box">
            <input type="text" name="search" placeholder="Search by name, gender, contact or city" value="<?= htmlspecialchars($search) ?>">
            <button type="submit"><i class="fas fa-search"></i> Search</button>
            <?php if (!empty($search)): ?>
                <a href="clients_list.php" class="action-btn" style="background-color: #f44336; color: white;">
                    <i class="fas fa-times"></i> Clear
                </a>
            <?php endif; ?>
        </form>
        
        <?php if (!empty($clients)): ?>
            <table class="client-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Gender</th>
                        <th>Age</th>
                        <th>Contact</th>
                        <th>City</th>
                        <th>Total Score</th>
                        <th>Actions</th> <!-- Removed Registered On column -->
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($clients as $client): ?>
                        <tr>
                            <td><?= htmlspecialchars($client['id']) ?></td>
                            <td><?= htmlspecialchars($client['name']) ?></td>
                            <td><?= htmlspecialchars($client['gender']) ?></td>
                            <td><?= htmlspecialchars($client['age']) ?></td>
                            <td><?= htmlspecialchars($client['contact']) ?></td>
                            <td><?= htmlspecialchars($client['city']) ?></td>
                            <td class="total-score"><?= htmlspecialchars($client['total']) ?></td>
                            <td>
							<a href="report.php?id=<?= $client['id'] ?>" class="action-btn view-btn">
								<i class="fas fa-file-alt"></i> View Report
							</a>
					<?php if ($is_admin): ?>
							<a href="edit_client.php?id=<?= $client['id'] ?>" class="action-btn" style="background-color: #ff9800; color: white;">
								<i class="fas fa-edit"></i> Edit
							</a>
					<?php endif; ?>
							</td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <?php if ($total_pages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?= $page-1 ?>&search=<?= urlencode($search) ?>"><i class="fas fa-chevron-left"></i></a>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <?php if ($i == $page): ?>
                            <span class="active"><?= $i ?></span>
                        <?php else: ?>
                            <a href="?page=<?= $i ?>&search=<?= urlencode($search) ?>"><?= $i ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <a href="?page=<?= $page+1 ?>&search=<?= urlencode($search) ?>"><i class="fas fa-chevron-right"></i></a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="no-clients">
                <i class="fas fa-user-slash" style="font-size: 48px; margin-bottom: 15px;"></i>
                <h3>No clients found</h3>
                <p>No fingerprint test records match your search criteria.</p>
            </div>
        <?php endif; ?>
    </div>
    <?php include 'includes/footer.php'; ?>
</body>
</html>