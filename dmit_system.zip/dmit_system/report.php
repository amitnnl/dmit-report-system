<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check authentication
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_message'] = "Please login to access client reports";
    header("Location: login.php");
    exit;
}

include 'config/db.php';

// Get client ID from URL parameter with validation
$client_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Validate client ID
if ($client_id <= 0) {
    $_SESSION['error'] = "Invalid client ID specified";
    header("Location: clients_list.php");
    exit;
}

// Verify permission (admin or owner)
$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;
$current_user_id = $_SESSION['user_id'];

// Fetch client information first to verify ownership
$query_client = "SELECT user_id FROM fingerprint_data WHERE id = ? LIMIT 1";
$stmt_client = $conn->prepare($query_client);
$stmt_client->bind_param("i", $client_id);
$stmt_client->execute();
$client_result = $stmt_client->get_result();

if ($client_result->num_rows === 0) {
    $_SESSION['error'] = "Client record not found";
    header("Location: clients_list.php");
    exit;
}

$client_data = $client_result->fetch_assoc();
$report_user_id = $client_data['user_id'];

// Check permissions
if (!$is_admin && $report_user_id != $current_user_id) {
    $_SESSION['error'] = "You don't have permission to access this client's report";
    header("Location: clients_list.php");
    exit;
}

// Fetch fingerprint data
$query_fingerprint = "SELECT * FROM fingerprint_data WHERE id = ? LIMIT 1";
$stmt_fingerprint = $conn->prepare($query_fingerprint);
$stmt_fingerprint->bind_param("i", $client_id);
$stmt_fingerprint->execute();
$result_fingerprint = $stmt_fingerprint->get_result();
$row = $result_fingerprint->fetch_assoc();

// Set default values if no fingerprint data exists
$default_fingerprint = [
    'L1' => 0, 'L2' => 0, 'L3' => 0, 'L4' => 0, 'L5' => 0, 'total_left' => 0,
    'R1' => 0, 'R2' => 0, 'R3' => 0, 'R4' => 0, 'R5' => 0, 'total_right' => 0,
    'total' => 1 // Default to 1 to avoid division by zero
];
$row = array_merge($default_fingerprint, $row ?: []);

// Fetch intelligence scores
$query_intelligence = "SELECT * FROM intelligence_scores WHERE user_id = ? ORDER BY id DESC LIMIT 1";
$stmt_intelligence = $conn->prepare($query_intelligence);
$stmt_intelligence->bind_param("i", $report_user_id);
$stmt_intelligence->execute();
$result_intelligence = $stmt_intelligence->get_result();
$data = $result_intelligence->fetch_assoc();

// Set default intelligence values
$default_intelligence = [
    'linguistic' => 0, 'logical' => 0, 'spatial' => 0, 'musical' => 0,
    'bodily' => 0, 'interpersonal' => 0, 'intrapersonal' => 0, 'naturalistic' => 0
];
$data = array_merge($default_intelligence, $data ?: []);

// Fetch career rankings
$query_career = "SELECT * FROM career_rankings WHERE user_id = ? ORDER BY id DESC LIMIT 1";
$stmt_career = $conn->prepare($query_career);
$stmt_career->bind_param("i", $report_user_id);
$stmt_career->execute();
$result_career = $stmt_career->get_result();
$rank_data = $result_career->fetch_assoc();

// Set default career values
$default_career = [
    'career1' => 'N/A', 'career2' => 'N/A', 'career3' => 'N/A',
    'career4' => 'N/A', 'career5' => 'N/A'
];
$rank_data = array_merge($default_career, $rank_data ?: []);

// Calculate brain dominance
$total = max(1, $row['total']); // Ensure we don't divide by zero
$left_percentage = ($row['total_left'] / $total) * 100;
$right_percentage = ($row['total_right'] / $total) * 100;

$difference = abs($left_percentage - $right_percentage);
$dominance = match(true) {
    $difference < 10 => "Balanced Brain",
    $left_percentage > $right_percentage => "Left Brain Dominant",
    default => "Right Brain Dominant"
};

// Include header after all processing is done
include 'includes/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>DMIT Report</title>
    <link rel="stylesheet" href="assets/css/main.css?v=<?= time(); ?>">
	<script src="assets/js/main.js?v=<?= time(); ?>"></script>
</head>
<body>
    <?php if (isset($row) && isset($data) && isset($rank_data)): ?>
    <div class="container">
        <div class="printable-content">
            <h2>DMIT Fingerprint Test Report</h2>

            <!-- Client Info -->
            <div class="card">
                <h3>Client Information</h3>
                <table>
                    <tr>
                        <th>User ID</th>
                        <th>Name</th>
                        <th>Gender</th>
                        <th>Age</th>
                        <th>Contact</th>
                        <th>City</th>
                        <th>Total</th>
                    </tr>
                    <tr>
                        <td><?= htmlspecialchars($row['user_id']) ?></td>
                        <td><?= htmlspecialchars($row['name']) ?></td>
                        <td><?= htmlspecialchars($row['gender']) ?></td>
                        <td><?= htmlspecialchars($row['age']) ?></td>
                        <td><?= htmlspecialchars($row['contact']) ?></td>
                        <td><?= htmlspecialchars($row['city']) ?></td>
                        <td><?= number_format($row['total'], 2) ?></td>
                    </tr>
                </table>
            </div>

            <!-- Grid layout -->
            <div class="grid-container">
                <!-- Column 1 -->
                <div class="column">
                    <div class="card">
                        <h3>Left Hand Fingerprint</h3>
                        <table>
                            <tr><th>Finger</th><th>Value</th></tr>
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <tr><td>L<?= $i ?></td><td><?= number_format($row["L$i"], 2) ?></td></tr>
                            <?php endfor; ?>
                            <tr><th>Total Left</th><th><?= number_format($row['total_left'], 2) ?></th></tr>
                        </table>
                    </div>

                    <div class="card">
                        <h3>Brain Lobe Analysis</h3>
                        <table>
                            <tr><th>Lobe</th><th>Percentage</th></tr>
                            <?php foreach (['prefrontal', 'frontal', 'parietal', 'temporal', 'occipital'] as $lobe): ?>
                                <tr><td><?= ucfirst($lobe) ?></td><td><?= number_format($data[$lobe], 2) ?>%</td></tr>
                            <?php endforeach; ?>
                        </table>
                    </div>

                    <div class="card">
                        <h3>Quotients</h3>
                        <table>
                            <tr><th>Type</th><th>Score</th></tr>
                            <?php foreach (['EQ', 'AQ'] as $q): ?>
                                <tr><td><?= $q ?></td><td><?= number_format($data[$q], 2) ?></td></tr>
                            <?php endforeach; ?>
                        </table>
                    </div>
                </div>

                <!-- Column 2 -->
                <div class="column">
                    <div class="card">
                        <h3>Right Hand Fingerprint</h3>
                        <table>
                            <tr><th>Finger</th><th>Value</th></tr>
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <tr><td>R<?= $i ?></td><td><?= number_format($row["R$i"], 2) ?></td></tr>
                            <?php endfor; ?>
                            <tr><th>Total Right</th><th><?= number_format($row['total_right'], 2) ?></th></tr>
                        </table>
                    </div>
                    
                    <div class="card">
                        <h3>Intelligence Types</h3>
                        <table>
                            <tr><th>Type</th><th>Score</th></tr>
                            <?php foreach (['intrapersonal', 'interpersonal', 'visual', 'logical', 'kinesthetic'] as $type): ?>
                                <tr><td><?= ucfirst($type) ?></td><td><?= number_format($data[$type], 2) ?></td></tr>
                            <?php endforeach; ?>
                        </table>
                    </div>
                    
                    <div class="card">
                        <h3>Quotients</h3>
                        <table>
                            <tr><th>Type</th><th>Score</th></tr>
                            <?php foreach (['IQ', 'CQ'] as $q): ?>
                                <tr><td><?= $q ?></td><td><?= number_format($data[$q], 2) ?></td></tr>
                            <?php endforeach; ?>
                        </table>
                    </div>
                </div>

                <!-- Column 3 -->
                <div class="column">
                    <div class="card">
                        <h3>Career Rankings Report</h3>
                        <table>
                            <tr><th>Field</th><th>Score</th></tr>
                            <?php
                            $fields = [
                                'information_tech' => 'Information Tech',
                                'engineering' => 'Engineering',
                                'mathematical' => 'Mathematical',
                                'medical' => 'Medical',
                                'life_science' => 'Life Science',
                                'earth_environment' => 'Earth Environment',
                                'construction_design' => 'Construction Design',
                                'artistry' => 'Artistry',
                                'sociology_psychology' => 'Sociology & Psychology',
                                'mass_communication' => 'Mass Communication',
                                'foreign_language' => 'Foreign Language',
                                'literature_history_philosophy' => 'Literature & History Philosophy',
                                'education' => 'Education',
                                'political_affair' => 'Political Affair',
                                'management' => 'Management',
                                'financial' => 'Finance',
                                'sports' => 'Sports',
                                'occult' => 'Occult',
                            ];
                            foreach ($fields as $key => $label):
                            ?>
                                <tr>
                                    <td><?= $label ?></td>
                                    <td><?= number_format($rank_data[$key], 2) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </table>
                    </div>
                    
                    <div class="action-buttons no-print">
                        <button class="export-btn" onclick="handleExport(<?= $user_id ?>)">
                            <i class="fas fa-file-export"></i> Export
                        </button>
                        <button class="print-btn" onclick="handlePrint()">
                            <i class="fas fa-print"></i> Print
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php else: ?>
        <p>No report data available.</p>
    <?php endif; ?>

    <script>
    function handlePrint() {
        window.print();
    }
    
    function handleExport(userId) {
        if (confirm("Do you want to export this report to Excel?")) {
            window.location.href = `pages/export_excel.php?user_id=${userId}`;
        }
    }
    </script>
	<?php include 'includes/footer.php'; ?>
</body>
</html>