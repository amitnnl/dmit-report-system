<?php
session_start();
include 'config/db.php';
require_once('tcpdf/tcpdf.php');

$user_id = $_GET['user_id'];

// Fetch data (same queries as in export to Excel)

// Create a new PDF document
$pdf = new TCPDF();
$pdf->AddPage();

// Set title
$pdf->SetFont('helvetica', 'B', 16);
$pdf->Cell(0, 10, 'DMIT Report', 0, 1, 'C');

// Add the content (similar to Excel export content)
$pdf->SetFont('helvetica', '', 12);

// Left Hand Fingerprint
$pdf->Cell(0, 10, 'Left Hand Fingerprint', 0, 1);
$pdf->Cell(50, 10, 'L1: ' . number_format($row['L1'], 2));
$pdf->Cell(50, 10, 'L2: ' . number_format($row['L2'], 2));
// Continue with the rest of the fields...

// Career Rankings
$pdf->Cell(0, 10, 'Career Rankings Report', 0, 1);
$pdf->Cell(50, 10, 'Information Tech: ' . number_format($rank_data['information_tech'], 2));
// Continue with the rest...

// Output PDF
$pdf->Output("DMIT_Report_User_{$user_id}.pdf", 'D');
exit;
?>
