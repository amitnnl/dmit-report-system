<?php
session_start();
include '../config/db.php';
require '../vendor/autoload.php'; // If you're using Composer

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$user_id = $_GET['user_id'];

// Fetch intelligence scores
$query = "SELECT * FROM intelligence_scores WHERE user_id = ? ORDER BY id DESC LIMIT 1";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();

// Fetch career rankings
$query_rank = "SELECT * FROM career_rankings WHERE user_id = ? ORDER BY id DESC LIMIT 1";
$stmt_rank = $conn->prepare($query_rank);
$stmt_rank->bind_param("i", $user_id);
$stmt_rank->execute();
$result_rank = $stmt_rank->get_result();
$rank_data = $result_rank->fetch_assoc();

// Fetch fingerprint data
$query_fingerprint = "SELECT * FROM fingerprint_data WHERE user_id = ? ORDER BY id DESC LIMIT 1";
$stmt_fingerprint = $conn->prepare($query_fingerprint);
$stmt_fingerprint->bind_param("i", $user_id);
$stmt_fingerprint->execute();
$result_fingerprint = $stmt_fingerprint->get_result();
$row = $result_fingerprint->fetch_assoc();

if (!$row) {
    $row = [
        'L1' => 0, 'L2' => 0, 'L3' => 0, 'L4' => 0, 'L5' => 0,
        'total_left' => 0, 'R1' => 0, 'R2' => 0, 'R3' => 0,
        'R4' => 0, 'R5' => 0, 'total_right' => 0
    ];
}

// Create new Spreadsheet
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Set Report Header
$sheet->setCellValue('A1', 'DMIT Report');
$sheet->mergeCells('A1:F1');
$sheet->getStyle('A1')->getFont()->setBold(true)->setSize(16);
$sheet->getStyle('A1')->getAlignment()->setHorizontal('center');

// Left Hand Fingerprint
$sheet->setCellValue('A2', 'Left Hand Fingerprint');
$sheet->setCellValue('A3', 'Finger');
$sheet->setCellValue('B3', 'Value');
$sheet->setCellValue('A4', 'L1');
$sheet->setCellValue('B4', $row['L1']);
$sheet->setCellValue('A5', 'L2');
$sheet->setCellValue('B5', $row['L2']);
$sheet->setCellValue('A6', 'L3');
$sheet->setCellValue('B6', $row['L3']);
$sheet->setCellValue('A7', 'L4');
$sheet->setCellValue('B7', $row['L4']);
$sheet->setCellValue('A8', 'L5');
$sheet->setCellValue('B8', $row['L5']);
$sheet->setCellValue('A9', 'Total Left');
$sheet->setCellValue('B9', $row['total_left']);

// Right Hand Fingerprint
$sheet->setCellValue('D2', 'Right Hand Fingerprint');
$sheet->setCellValue('D3', 'Finger');
$sheet->setCellValue('E3', 'Value');
$sheet->setCellValue('D4', 'R1');
$sheet->setCellValue('E4', $row['R1']);
$sheet->setCellValue('D5', 'R2');
$sheet->setCellValue('E5', $row['R2']);
$sheet->setCellValue('D6', 'R3');
$sheet->setCellValue('E6', $row['R3']);
$sheet->setCellValue('D7', 'R4');
$sheet->setCellValue('E7', $row['R4']);
$sheet->setCellValue('D8', 'R5');
$sheet->setCellValue('E8', $row['R5']);
$sheet->setCellValue('D9', 'Total Right');
$sheet->setCellValue('E9', $row['total_right']);

// Brain Lobe Analysis
$sheet->setCellValue('A11', 'Brain Lobe Analysis');
$sheet->setCellValue('A12', 'Lobe');
$sheet->setCellValue('B12', 'Percentage');
$sheet->setCellValue('A13', 'Prefrontal');
$sheet->setCellValue('B13', $data['prefrontal']);
$sheet->setCellValue('A14', 'Frontal');
$sheet->setCellValue('B14', $data['frontal']);
$sheet->setCellValue('A15', 'Parietal');
$sheet->setCellValue('B15', $data['parietal']);
$sheet->setCellValue('A16', 'Temporal');
$sheet->setCellValue('B16', $data['temporal']);
$sheet->setCellValue('A17', 'Occipital');
$sheet->setCellValue('B17', $data['occipital']);

// Intelligence Types
$sheet->setCellValue('A19', 'Intelligence Types');
$sheet->setCellValue('A20', 'Type');
$sheet->setCellValue('B20', 'Score');
$sheet->setCellValue('A21', 'Intrapersonal');
$sheet->setCellValue('B21', $data['intrapersonal']);
$sheet->setCellValue('A22', 'Interpersonal');
$sheet->setCellValue('B22', $data['interpersonal']);
$sheet->setCellValue('A23', 'Visual');
$sheet->setCellValue('B23', $data['visual']);
$sheet->setCellValue('A24', 'Logical');
$sheet->setCellValue('B24', $data['logical']);
$sheet->setCellValue('A25', 'Kinesthetic');
$sheet->setCellValue('B25', $data['kinesthetic']);

// Career Rankings
$sheet->setCellValue('D11', 'Career Rankings Report');
$sheet->setCellValue('D12', 'Field');
$sheet->setCellValue('E12', 'Score');
$fields = [
    'Information Tech' => $rank_data['information_tech'],
    'Engineering' => $rank_data['engineering'],
    'Mathematical' => $rank_data['mathematical'],
    'Medical' => $rank_data['medical'],
    'Life Science' => $rank_data['life_science'],
    'Environment' => $rank_data['earth_environment'],
    'Construction' => $rank_data['construction_design'],
    'Artistry' => $rank_data['artistry'],
    'Psychology' => $rank_data['sociology_psychology'],
    'Communication' => $rank_data['mass_communication'],
    'Language' => $rank_data['foreign_language'],
    'History' => $rank_data['literature_history_philosophy'],
    'Education' => $rank_data['education'],
    'Politics' => $rank_data['political_affair'],
    'Management' => $rank_data['management'],
    'Finance' => $rank_data['financial'],
    'Sports' => $rank_data['sports'],
    'Occult' => $rank_data['occult'],
];

$row_num = 13;
foreach ($fields as $field => $score) {
    $sheet->setCellValue('D' . $row_num, $field);
    $sheet->setCellValue('E' . $row_num, $score);
    $row_num++;
}

// Save Excel file
$writer = new Xlsx($spreadsheet);
$filename = "DMIT_Report_User_{$user_id}.xlsx";
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="' . $filename . '"');
header('Cache-Control: max-age=0');
$writer->save('php://output');
exit;
?>
