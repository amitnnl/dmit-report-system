<?php
// Session and auth check remain unchanged
include 'config/db.php';
include 'includes/header.php';
?>

<main class="container">
  <div class="dashboard">
    <!-- Enhanced Header -->
    <header class="dashboard-header">
      <div class="header-content">
        <h2 class="dashboard-title">DMIT Report System Dashboard</h2>
        <p class="dashboard-subtitle">Fingerprint Analysis & Career Intelligence Platform</p>
        <div class="dashboard-meta">
          <span class="live-date"><?php echo date('M j, Y'); ?></span>
          <span class="user-role">Logged in as: <?php echo $_SESSION['username']; ?></span>
        </div>
      </div>
    </header>

    <!-- Professional Search Bar -->
    <section class="search-section">
      <form method="GET" action="search.php" class="professional-search">
        <div class="input-group">
          <span class="input-icon">
            <i class="fas fa-search"></i>
          </span>
          <input type="text" 
                 id="searchInput" 
                 name="query" 
                 placeholder="Search client, report ID, or keyword..."
                 class="search-field">
          <button type="submit" class="search-action">
            <span>Search</span>
            <i class="fas fa-arrow-right-long"></i>
          </button>
        </div>
      </form>
    </section>

    <!-- Professional Stats Grid -->
    <section class="metric-grid">
      <div class="metric-card">
        <div class="metric-icon">
          <i class="fas fa-user-graduate"></i>
        </div>
        <div class="metric-content">
          <h3 class="metric-label">Processed Profiles</h3>
          <div class="metric-value">1,024</div>
          <div class="metric-trend positive">
            <i class="fas fa-arrow-up"></i> 12% last month
          </div>
        </div>
      </div>

      <div class="metric-card">
        <div class="metric-icon">
          <i class="fas fa-fingerprint"></i>
        </div>
        <div class="metric-content">
          <h3 class="metric-label">Fingerprint Scans</h3>
          <div class="metric-value">784</div>
          <div class="metric-trend">
            <i class="fas fa-arrow-right"></i> Steady
          </div>
        </div>
      </div>

      <!-- Add other metric cards similarly -->
    </section>

    <!-- Enhanced Chart Section -->
    <div class="analytics-container">
      <div class="main-chart">
        <h4 class="chart-title">Intelligence Distribution Analysis</h4>
        <canvas id="barChart"></canvas>
      </div>
      
      <div class="secondary-chart">
        <h4 class="chart-title">Pattern Category Breakdown</h4>
        <div id="nightingaleChart"></div>
      </div>
    </div>
  </div>
</main>
<?php include 'includes/footer.php'; ?>