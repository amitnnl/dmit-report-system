<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    die("Error: User not logged in.");
}

$user_id = $_SESSION['user_id'];

// 1. Get Fingerprint Data (Excel Columns A-H)
$fp_query = "SELECT * FROM fingerprint_data WHERE user_id = ? ORDER BY id DESC LIMIT 1";
$fp_stmt = $conn->prepare($fp_query);
$fp_stmt->bind_param("i", $user_id);
$fp_stmt->execute();
$fp_data = $fp_stmt->get_result()->fetch_assoc();
$fp_stmt->close();

if (!$fp_data) {
    die("Error: No fingerprint data found.");
}

// 2. Calculate All Values Exactly Like Excel
// ========================================

// Excel J9 (Total Sum)
$J9 = $fp_data['L1'] + $fp_data['L2'] + $fp_data['L3'] + $fp_data['L4'] + $fp_data['L5']
    + $fp_data['R1'] + $fp_data['R2'] + $fp_data['R3'] + $fp_data['R4'] + $fp_data['R5'];

// Excel J11 (KAV Sum)
$J11 = $fp_data['L3'] + $fp_data['R3'] + $fp_data['L4'] + $fp_data['R4'] + $fp_data['L5'] + $fp_data['R5'];

// Brain Regions (Excel J4-J8)
$J4 = ($fp_data['L1'] + $fp_data['R1']) / $J9 * 100; // Pre Frontal
$J5 = ($fp_data['L2'] + $fp_data['R2']) / $J9 * 100; // Frontal
$J6 = ($fp_data['L3'] + $fp_data['R3']) / $J9 * 100; // Parietal
$J7 = ($fp_data['L4'] + $fp_data['R4']) / $J9 * 100; // Temporal
$J8 = ($fp_data['L5'] + $fp_data['R5']) / $J9 * 100; // Occipital

// Intelligence Types (Excel P4-P11)
$P4 = $fp_data['R1'];  // Intrapersonal (H4)
$P5 = $fp_data['L1'];  // Interpersonal (D4)
$P6 = $fp_data['L2'];  // Visual (D5)
$P7 = $fp_data['R2'];  // Logical (H5)
$P8 = ($fp_data['L3'] + $fp_data['R3']) / 2; // Kinesthetic (J6/2)
$P9 = $fp_data['L4'];  // Musical (D7)
$P10 = $fp_data['R4']; // Linguistic (H7)
$P11 = $fp_data['R5']; // Naturalist (H8)

// Quotients (Excel T4-T7)
$T4 = $P4 + $P5; // EQ
$T5 = $P8 + $P11; // AQ
$T6 = $P10 + $P7; // IQ
$T7 = $P6 + $P9;  // CQ
$T8 = $T4 + $T5 + $T6 + $T7; // Sum of quotients

// Special Calculations
$MOT = $fp_data['R5'] / $J9 * 100; // MOT (H9/J9*100)
$REF = $fp_data['L5'] / $J9 * 100; // REF (D9/J9*100)

// 3. Save Intelligence Scores
$intel_stmt = $conn->prepare("INSERT INTO intelligence_scores 
    (user_id, prefrontal, frontal, parietal, temporal, occipital, 
    intrapersonal, interpersonal, visual, logical, kinesthetic, musical, linguistic, naturalist,
    EQ, AQ, IQ, CQ, MOT, REF) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE 
    prefrontal=VALUES(prefrontal), frontal=VALUES(frontal), parietal=VALUES(parietal),
    temporal=VALUES(temporal), occipital=VALUES(occipital), intrapersonal=VALUES(intrapersonal),
    interpersonal=VALUES(interpersonal), visual=VALUES(visual), logical=VALUES(logical),
    kinesthetic=VALUES(kinesthetic), musical=VALUES(musical), linguistic=VALUES(linguistic),
    naturalist=VALUES(naturalist), EQ=VALUES(EQ), AQ=VALUES(AQ), IQ=VALUES(IQ),
    CQ=VALUES(CQ), MOT=VALUES(MOT), REF=VALUES(REF)");

$intel_stmt->bind_param("iddddddddddddddddddd", 
    $user_id, $J4, $J5, $J6, $J7, $J8,
    $P4, $P5, $P6, $P7, $P8, $P9, $P10, $P11,
    $T4, $T5, $T6, $T7, $MOT, $REF
);
$intel_stmt->execute();
$intel_stmt->close();

// 4. Calculate Career Scores (Excel W4-W21)
// ========================================

$career_scores = [
    'information_tech'    => $P7 + $P6,                   // W4
    'engineering'         => $P7 + $P6 + $P11,            // W5
    'mathematical'        => $P7 + $P11,                  // W6
    'medical'             => $P7 + $P9 + ($T5/100),       // W7 (Q11 = AQ/100)
    'life_science'        => $P11 + $P7,                  // W8
    'earth_environment'   => $P11 + $P6 + $P7,            // W9
    'construction_design' => $P6 + $P7,                   // W10
    'artistry'            => $P9 + $P10 + $P6,            // W11
    'sociology_psychology'=> $P4 + $P5,                   // W12
    'mass_communication'  => $P10 + $P6 + $P9,            // W13
    'foreign_language'    => $P10 + $P5,                  // W14
    'literature_history_philosophy' => $P10 + $P4,        // W15
    'education'           => $P10 + $P5,                  // W16
    'political_affair'    => $P10 + $P7 + $P5,            // W17
    'management'          => $P4 + $P5 + $P10,            // W18
    'financial'           => $P7,                         // W19
    'sports'              => $P8,                         // W20
    'occult'              => $P10 + $P7 + $P5             // W21
];

// 5. Apply Weights (Excel Y4-Y21)
$weighted_scores = [];
foreach ($career_scores as $field => $score) {
    // Determine divisor (2 or 3) based on Excel Y column
    $divisor = in_array($field, [
        'engineering', 'medical', 'earth_environment', 'mass_communication',
        'political_affair', 'management', 'occult'
    ]) ? 3 : 2;
    
    $weighted_scores[$field] = $score / $divisor;
}

// 6. Save Career Rankings
$career_columns = implode(", ", array_keys($weighted_scores));
$placeholders = implode(", ", array_fill(0, count($weighted_scores), "?"));
$updates = implode(", ", array_map(fn($col) => "$col=VALUES($col)", array_keys($weighted_scores)));

$career_stmt = $conn->prepare("INSERT INTO career_rankings 
    (user_id, $career_columns) VALUES (?, $placeholders)
    ON DUPLICATE KEY UPDATE $updates");

$career_types = "i" . str_repeat("d", count($weighted_scores));
$career_params = array_merge([$user_id], array_values($weighted_scores));
$career_stmt->bind_param($career_types, ...$career_params);
$career_stmt->execute();
$career_stmt->close();

// 7. Redirect to Report
header("Location: report.php");
exit;

$conn->close();
?>