// ----------- Theme Toggle -----------
function setTheme(theme) {
    document.body.className = theme;
    document.documentElement.setAttribute('data-theme', theme === 'dark-theme' ? 'dark' : 'light');
    document.cookie = "theme=" + theme + "; path=/; max-age=31536000"; // 1 year
}

function toggleTheme() {
    const current = document.body.className;
    const newTheme = current === 'dark-theme' ? 'light-theme' : 'dark-theme';
    setTheme(newTheme);
}

// Optional: Add a button with onclick="toggleTheme()" in your layout

// ----------- Profile Dropdown Animation -----------
function toggleProfileMenu() {
    const menu = document.getElementById('profileMenu');
    if (!menu) return;
    
    menu.classList.toggle('show');
    menu.style.opacity = menu.classList.contains('show') ? '1' : '0';
    menu.style.transform = menu.classList.contains('show') ? 'translateY(0)' : 'translateY(-10px)';
}

window.addEventListener('click', function (e) {
    if (!e.target.closest('.profile')) {
        const menu = document.getElementById('profileMenu');
        if (menu) {
            menu.classList.remove('show');
            menu.style.opacity = '0';
            menu.style.transform = 'translateY(-10px)';
        }
    }
});

// ----------- On Load Apply Theme from Cookie -----------
window.addEventListener('DOMContentLoaded', () => {
    const cookies = document.cookie.split(';').reduce((acc, cookie) => {
        const [name, val] = cookie.trim().split('=');
        acc[name] = val;
        return acc;
    }, {});

    if (cookies.theme) {
        setTheme(cookies.theme);
    }
});
// Scroll effect
window.addEventListener("scroll", () => {
  const header = document.querySelector(".header");
  header.classList.toggle("scrolled", window.scrollY > 10);
});

// In dashboard.js
document.addEventListener('DOMContentLoaded', function() {
  // Animate counters
  animateCounters();
  
  // Initialize charts
  initRadarChart();
  initDonutChart();
  
  // Live clock
  updateClock();
  setInterval(updateClock, 1000);
  
  // Search suggestions
  initSearchTypeahead();
});