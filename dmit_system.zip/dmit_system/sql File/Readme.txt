 User id - admin
 Password - Admin@123
 
 🚀 Next Steps for Improvement
 
📌 Add Export Feature (Excel & PDF)

📊 Integrate Chart.js for Visual Reports

🔒 Implement User Role Management (Admin/Staff)

📜 Improve Print Styling for Reports

🛠️ Debug & Optimize Code for Speed

Which one would you like to prioritize first? 🚀

dmit_system/
│
├── index.php               ✅ (this is your main file)
├── config/
│   └── db.php              ✅ (your database connection)
├── includes/
│   ├── header.php
│   └── footer.php
├── assets/
│   └── css/
│       └── style.css       ✅ (basic style)
├── uploads/
│   └── logo.png            ✅ (logo)
├── calculate_scores.php    ✅ (calculation logic)
├── calculate_ranks.php     ✅ (career ranking logic)
├── report.php              ✅ (output page)
├── logout.php              ✅ (session destroy file)
└── pages/
    └── reset_password.php  ✅ (optional)
