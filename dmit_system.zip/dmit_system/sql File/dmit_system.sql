-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2025 at 11:11 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dmit_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `career_rankings`
--

CREATE TABLE `career_rankings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `information_tech` double DEFAULT NULL,
  `engineering` double DEFAULT NULL,
  `mathematical` double DEFAULT NULL,
  `medical` double DEFAULT NULL,
  `life_science` double DEFAULT NULL,
  `earth_environment` double DEFAULT NULL,
  `construction_design` double DEFAULT NULL,
  `artistry` double DEFAULT NULL,
  `sociology_psychology` double DEFAULT NULL,
  `mass_communication` double DEFAULT NULL,
  `foreign_language` double DEFAULT NULL,
  `literature_history_philosophy` double DEFAULT NULL,
  `education` double DEFAULT NULL,
  `political_affair` double DEFAULT NULL,
  `management` double DEFAULT NULL,
  `financial` double DEFAULT NULL,
  `sports` double DEFAULT NULL,
  `occult` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `career_rankings`
--

INSERT INTO `career_rankings` (`id`, `user_id`, `information_tech`, `engineering`, `mathematical`, `medical`, `life_science`, `earth_environment`, `construction_design`, `artistry`, `sociology_psychology`, `mass_communication`, `foreign_language`, `literature_history_philosophy`, `education`, `political_affair`, `management`, `financial`, `sports`, `occult`) VALUES
(50, 1, 9, 11.333333333333334, 14, 5.076666666666667, 14, 11.333333333333334, 9, 7, 13.5, 4.666666666666667, 9, 9.5, 9, 10, 10.666666666666666, 6, 3.5, 10),
(51, 1, 9, 11.333333333333334, 14, 5.076666666666667, 14, 11.333333333333334, 9, 7, 13.5, 4.666666666666667, 9, 9.5, 9, 10, 10.666666666666666, 6, 3.5, 10);

-- --------------------------------------------------------

--
-- Table structure for table `fingerprint_data`
--

CREATE TABLE `fingerprint_data` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `L1` int(11) DEFAULT NULL,
  `L2` int(11) DEFAULT NULL,
  `L3` int(11) DEFAULT NULL,
  `L4` int(11) DEFAULT NULL,
  `L5` int(11) DEFAULT NULL,
  `R1` int(11) DEFAULT NULL,
  `R2` int(11) DEFAULT NULL,
  `R3` int(11) DEFAULT NULL,
  `R4` int(11) DEFAULT NULL,
  `R5` int(11) DEFAULT NULL,
  `total_left` int(11) DEFAULT NULL,
  `total_right` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fingerprint_data`
--

INSERT INTO `fingerprint_data` (`id`, `user_id`, `L1`, `L2`, `L3`, `L4`, `L5`, `R1`, `R2`, `R3`, `R4`, `R5`, `total_left`, `total_right`, `total`, `name`, `gender`, `age`, `contact`, `city`) VALUES
(220, 1, 13, 6, 4, 3, 13, 14, 12, 10, 5, 16, 39, 57, 96, 'Amit Jangid', 'Male', 45, '9416341097', 'Narnaul'),
(224, 1, 13, 6, 4, 3, 13, 14, 12, 10, 5, 16, 39, 57, 96, 'Piyush Jangid', 'Male', 19, '9416075933', 'Narnaul');

-- --------------------------------------------------------

--
-- Table structure for table `intelligence_scores`
--

CREATE TABLE `intelligence_scores` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `prefrontal` float DEFAULT NULL,
  `frontal` float DEFAULT NULL,
  `parietal` float DEFAULT NULL,
  `temporal` float DEFAULT NULL,
  `occipital` float DEFAULT NULL,
  `EQ` float DEFAULT NULL,
  `AQ` float DEFAULT NULL,
  `IQ` float DEFAULT NULL,
  `CQ` float DEFAULT NULL,
  `MOT` float DEFAULT NULL,
  `REF` float DEFAULT NULL,
  `intrapersonal` float DEFAULT NULL,
  `interpersonal` float DEFAULT NULL,
  `visual` float DEFAULT NULL,
  `logical` float DEFAULT NULL,
  `kinesthetic` float DEFAULT NULL,
  `musical` float DEFAULT NULL,
  `linguistic` float DEFAULT NULL,
  `naturalist` float DEFAULT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `sum_left` double DEFAULT NULL,
  `sum_right` double DEFAULT NULL,
  `sum_brain` double DEFAULT NULL,
  `grand_total` double DEFAULT NULL,
  `left_ratio` double DEFAULT NULL,
  `right_ratio` double DEFAULT NULL,
  `brain_ratio` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `intelligence_scores`
--

INSERT INTO `intelligence_scores` (`id`, `user_id`, `prefrontal`, `frontal`, `parietal`, `temporal`, `occipital`, `EQ`, `AQ`, `IQ`, `CQ`, `MOT`, `REF`, `intrapersonal`, `interpersonal`, `visual`, `logical`, `kinesthetic`, `musical`, `linguistic`, `naturalist`, `status`, `sum_left`, `sum_right`, `sum_brain`, `grand_total`, `left_ratio`, `right_ratio`, `brain_ratio`) VALUES
(187, 1, 28.125, 18.75, 14.5833, 8.33333, 30.2083, 27, 23, 17, 9, 16.6667, 13.5417, 14, 13, 6, 12, 7, 3, 5, 16, 'pending', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(188, 1, 28.125, 18.75, 14.5833, 8.33333, 30.2083, 27, 23, 17, 9, 16.6667, 13.5417, 14, 13, 6, 12, 7, 3, 5, 16, 'pending', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `status`) VALUES
(1, 'admin', '$2y$10$NSCefSEcm6Qa4JGz.A8tX.tKGxTtFyezI1/06OedzV//YyG//BFZu', 'active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `career_rankings`
--
ALTER TABLE `career_rankings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `fingerprint_data`
--
ALTER TABLE `fingerprint_data`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `intelligence_scores`
--
ALTER TABLE `intelligence_scores`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `career_rankings`
--
ALTER TABLE `career_rankings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `fingerprint_data`
--
ALTER TABLE `fingerprint_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=225;

--
-- AUTO_INCREMENT for table `intelligence_scores`
--
ALTER TABLE `intelligence_scores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=189;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `career_rankings`
--
ALTER TABLE `career_rankings`
  ADD CONSTRAINT `career_rankings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `fingerprint_data`
--
ALTER TABLE `fingerprint_data`
  ADD CONSTRAINT `fingerprint_data_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `intelligence_scores`
--
ALTER TABLE `intelligence_scores`
  ADD CONSTRAINT `intelligence_scores_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
