<?php
// Secure session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect unauthenticated users (except on index.php)
$current_page = basename($_SERVER['PHP_SELF']);
if (!isset($_SESSION['user_id']) && $current_page !== 'index.php') {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <title>Dermatoglyphics Multiple Intelligence Test</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Styles -->
    <link rel="stylesheet" href="assets/css/main.css?v=<?= time(); ?>">
	<link rel="stylesheet" href="assets/css/dash.css?v=<?= time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="<?= isset($_COOKIE['theme']) ? $_COOKIE['theme'] : 'light-theme' ?>">

<!-- Header -->
<header class="header">
    <div class="header__content">
	  <h4 class="header__logo_text">	
        <div class="header__brand">
            <a href="dashboard.php" class="logo">
                <i class="fas fa-brain logo__icon"></i>
                <span class="logo__text">DMIT Testing System</span>
            </a>
        </div>
	  </h4>
        <nav class="nav">
            <ul class="nav__list">
                <li class="nav__item <?= $current_page == 'dashboard.php' ? 'active' : '' ?>">
                    <a href="dashboard.php" class="nav__link">
                        <i class="fas fa-tachometer-alt nav__icon"></i>
                        <span class="nav__text">Dashboard</span>
                    </a>
                </li>
                <li class="nav__item <?= $current_page == 'index.php' ? 'active' : '' ?>">
                    <a href="index.php" class="nav__link">
                        <i class="fas fa-fingerprint nav__icon"></i>
                        <span class="nav__text">Scan Fingers</span>
                    </a>
                </li>
				<li class="nav__item <?= $current_page == 'clients_list.php' ? 'active' : '' ?>">
                    <a href="clients_list.php" class="nav__link">
                        <i class="fas fa-user"></i>
                        <span class="nav__text">Client List</span>
                    </a>
                </li>
                
                <li class="nav__item <?= $current_page == 'settings.php' ? 'active' : '' ?>">
                    <a href="#" class="nav__link">
                        <i class="fas fa-cog nav__icon"></i>
                        <span class="nav__text">Settings</span>
                    </a>
                </li>
				
            </ul>
        </nav>

        <div class="profile">
            <button class="profile__toggle" onclick="toggleProfileMenu()">
                <i class="fas fa-user-circle profile__icon"></i>
                <span class="profile__text">Profile</span>
                <i class="fas fa-chevron-down profile__caret"></i>
            </button>
            <div class="profile__menu" id="profileMenu">
                <a href="#" class="profile__item">
                    <i class="fas fa-id-badge profile__menu-icon"></i>
                    My Profile
                </a>
                <a href="pages/logout.php" class="profile__item">
                    <i class="fas fa-sign-out-alt profile__menu-icon"></i>
                    Logout
                </a>
            </div>
        </div>
    </div>
</header>

<!-- JS for profile toggle -->
<script>
    function toggleProfileMenu() {
        document.getElementById('profileMenu').classList.toggle('show');
    }

    // Optional: Close menu if clicked outside
    window.addEventListener('click', function(e) {
        if (!e.target.closest('.profile')) {
            document.getElementById('profileMenu')?.classList.remove('show');
        }
    });
</script>

<!-- Load custom JS at end of body for better performance -->
<script src="assets/js/main.js?v=<?= time(); ?>"></script>
