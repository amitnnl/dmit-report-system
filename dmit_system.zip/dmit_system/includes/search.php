<?php
include 'config/db.php'; // Include database connection

if (isset($_GET['query'])) {
    $search = trim($_GET['query']);
    
    // Query to search in multiple columns
    $sql = "SELECT * FROM reports 
            WHERE client_name LIKE ? 
            OR fingerprint_id LIKE ? 
            OR intelligence_score LIKE ? 
            OR career_ranking LIKE ?";
    
    $stmt = $conn->prepare($sql);
    $searchTerm = "%$search%";
    $stmt->bind_param("ssss", $searchTerm, $searchTerm, $searchTerm, $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<table>
                <tr>
                    <th>Client Name</th>
                    <th>Fingerprint ID</th>
                    <th>Intelligence Score</th>
                    <th>Career Ranking</th>
                    <th>Actions</th>
                </tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['client_name']}</td>
                    <td>{$row['fingerprint_id']}</td>
                    <td>{$row['intelligence_score']}</td>
                    <td>{$row['career_ranking']}</td>
                    <td>
                        <a href='view_report.php?id={$row['id']}' target='_blank'>View</a> |
                        <a href='export.php?id={$row['id']}'>Export</a> |
                        <a href='print.php?id={$row['id']}' onclick='window.print()'>Print</a>
                    </td>
                  </tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No results found.</p>";
    }
    exit; // Stop further execution after sending search results
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>DMIT Search Reports</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/main.css?v=<?= time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- Your Custom JS Files -->
    <script src="assets/js/main.js"></script>
</head>
<body>
    <h2>Search Reports</h2>
    <input type="text" id="searchInput" placeholder="Enter Client Name, Fingerprint ID, Score..." onkeyup="searchReports()">
    <div id="searchResults"></div>

    <script>
        function searchReports() {
            var query = $("#searchInput").val();
            if (query.length > 2) { // Start search only if input is at least 3 characters
                $.get("search.php", { query: query }, function(data) {
                    $("#searchResults").html(data);
                });
            } else {
                $("#searchResults").html(""); // Clear results if input is too short
            }
        }
    </script>
</body>
</html>
