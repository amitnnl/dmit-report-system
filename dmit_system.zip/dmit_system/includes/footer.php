<!-- Footer Section -->
<footer class="footer">
  <div class="footer__content">
    <!-- Scroll to Top Button -->
    <button class="footer__scroll-top" id="scrollTopBtn" aria-label="Scroll to top">
      <i class="fas fa-arrow-up"></i>
    </button>

    <div class="footer__sections">
      <!-- Brand Section -->
      <div class="footer__brand">
        <a href="index.php" class="footer__logo">
          <i class="fas fa-brain footer__logo-icon"></i>
          <h3 class="footer__logo-text">Fingerprint Testing</h3>
        </a>
        <h4 class="footer__description">Near Dwarka Mor Metro Station, #1416, Top Floor, Mohan Garden, Delhi-110059</h4>
      </div>

      <!-- Newsletter Section -->
      <div class="footer__newsletter">
        <h4 class="footer__heading">Stay Updated</h4>
        <form class="footer__form">
		<br>
          <div class="footer__input-group">
            <input type="email" class="footer__input" placeholder="Enter your email" required>
            <button type="submit" class="btn btn--icon">
              <i class="fas fa-paper-plane"></i>
            </button>
          </div>
        </form>
      </div>

      <!-- Quick Links -->
      <div class="footer__links">
        <h4 class="footer__heading">Quick Links</h4>
        <ul class="footer__list">
          <li class="footer__list-item">
            <a href="privacy.php" class="footer__link">
              <i class="fas fa-user-secret footer__link-icon"></i>
              Privacy Policy
            </a>
          </li>
          <li class="footer__list-item">
            <a href="terms.php" class="footer__link">
              <i class="fas fa-file-contract footer__link-icon"></i>
              Terms & Conditions
            </a>
          </li>
        </ul>
      </div>

      <!-- Social Links -->
      <div class="footer__social">
        <h4 class="footer__heading">Connect With Us</h4>
        <div class="footer__social-icons">
          <a href="#" class="footer__social-link" aria-label="Facebook">
            <i class="fab fa-facebook-f"></i>
          </a>
          <a href="#" class="footer__social-link" aria-label="Twitter">
            <i class="fab fa-x-twitter"></i>
          </a>
          <a href="#" class="footer__social-link" aria-label="LinkedIn">
            <i class="fab fa-linkedin-in"></i>
          </a>
          <a href="#" class="footer__social-link" aria-label="Instagram">
            <i class="fab fa-instagram"></i>
          </a>
          <a href="#" class="footer__social-link" aria-label="YouTube">
            <i class="fab fa-youtube"></i>
          </a>
        </div>
      </div>
    </div>

    <div class="footer__bottom">
      <p class="footer__copyright">
        &copy; <?= date('Y') ?> <strong>DMIT System</strong>. All rights reserved.
      </p>
    </div>
  </div>
</footer>

<!-- JavaScript Files -->
<script src="assets/js/script.js?v=<?php echo time(); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>

<script>
/* Add this to your JS for extra animation */
document.querySelectorAll('.footer__social-link').forEach(link => {
  link.addEventListener('mouseover', () => {
    link.style.animation = 'float 0.8s ease-in-out';
  });
  link.addEventListener('mouseout', () => {
    link.style.animation = '';
  });
});
  // Scroll to Top Functionality
const scrollButton = document.getElementById('scrollTopBtn');

window.addEventListener('scroll', () => {
  const scrollY = window.scrollY || document.documentElement.scrollTop;
  scrollButton.classList.toggle('show', scrollY > 200);
});

scrollButton.addEventListener('click', () => {
  window.scrollTo({
    top: 0,
    behavior: 'smooth'
  });
});
</script>

</body>
</html>
