<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

require 'db.php'; // Ensure this connects to your DB

// Fetch total clients
$total_clients_query = "SELECT COUNT(*) AS total FROM clients";
$total_clients_result = $conn->query($total_clients_query);
$total_clients = $total_clients_result->fetch_assoc()['total'];

// Fetch total sales
$total_sales_query = "SELECT COUNT(*) AS total FROM sales";
$total_sales_result = $conn->query($total_sales_query);
$total_sales = $total_sales_result->fetch_assoc()['total'];

// Fetch total revenue from purchases
$total_clients_revenue_query = "SELECT SUM(paid_amount) AS total FROM clients";
$total_clients_revenue_result = $conn->query($total_clients_revenue_query);
$total_clients_revenue = $total_clients_revenue_result->fetch_assoc()['total'] ?? 0;

// Fetch total revenue from sales
$total_sales_revenue_query = "SELECT SUM(paid_amount) AS total FROM sales";
$total_sales_revenue_result = $conn->query($total_sales_revenue_query);
$total_sales_revenue = $total_sales_revenue_result->fetch_assoc()['total'] ?? 0;

// Calculate total revenue
$total_revenue = $total_clients_revenue + $total_sales_revenue;

// Fetch total balance amount (Remaining balance from all clients and sales)
$total_balance_amount_query = "SELECT SUM(balance_amount) AS total FROM (SELECT balance_amount FROM clients UNION ALL SELECT balance_amount FROM sales) AS all_balances";
$total_balance_amount_result = $conn->query($total_balance_amount_query);
$total_balance_amount_revenue = $total_balance_amount_result->fetch_assoc()['total'] ?? 0;

// Fetch total purchase balance
$total_purchase_balance_query = "SELECT SUM(balance_amount) AS total FROM clients";
$total_purchase_balance_result = $conn->query($total_purchase_balance_query);
$total_purchase_balance = $total_purchase_balance_result->fetch_assoc()['total'] ?? 0;

// Fetch total sales balance
$total_sales_balance_query = "SELECT SUM(balance_amount) AS total FROM sales";
$total_sales_balance_result = $conn->query($total_sales_balance_query);
$total_sales_balance = $total_sales_balance_result->fetch_assoc()['total'] ?? 0;
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Shri Shyam Motors</title>
    <link href="bootstrap-5.0.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="bootstrap-5.0.2/js/bootstrap.bundle.min.js"></script>
    <style>
        body { background-color: #f8f9fa; font-family: 'Arial', sans-serif; }
        .navbar { background-color: #212529; padding: 5px; }
        .card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2); }
        .search-box { max-width: 750px; margin: 20px auto; }
        .footer { background-color: #343a40; color: white; text-align: center; padding: 5px; position: fixed; bottom: 0; width: 100%; }
    </style>
</head>
<body>
<!-- 🚗 Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Shri Shyam Motors</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">🏠 Dashboard</a></li>

                <!-- Purchase Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="purchaseDropdown" role="button" data-bs-toggle="dropdown">
                        📋 Purchase
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="purchaseDropdown">
                        <li><a class="dropdown-item" href="client_form.php">➕ Add Purchase</a></li>
                        <li><a class="dropdown-item" href="view_clients.php">📜 Purchase History</a></li>
                    </ul>
                </li>

                <!-- Sales Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="salesDropdown" role="button" data-bs-toggle="dropdown">
                        🚗 Sales
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="salesDropdown">
                        <li><a class="dropdown-item" href="sales_form.php">➕ Add Sale</a></li>
                        <li><a class="dropdown-item" href="view_sales.php">📜 Sales History</a></li>
                    </ul>
                </li>

                <li class="nav-item"><a class="nav-link" href="reports.php">📊 Reports</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">🔒 Logout</a></li>
            </ul>
        </div>
    </div>
</nav>
    <!-- 🚗 Dashboard -->
    <div class="container mt-4">	
    <div class="row">
		
        <!-- Left Section (Company Info & Search) -->
        <div class="col-md-5">
            <div class="card mx-auto" style="max-width: 400px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2); border-radius: 12px; overflow: hidden; background: linear-gradient(135deg, #f9f9f9, #fff); text-align: center; padding: 30px;">
		<div class="card-avatar" style="margin-bottom: 15px;">
			<img src="uploads/logo01.png" alt="Shri Shyam Motors Logo" style="width: 180px; height: 150px; border: 0px solid #ddd;">
		</div>
			<h3 style="color: #333; font-weight: bold;">Welcome, <strong><?= htmlspecialchars($_SESSION['username']); ?></strong>!</h3>
				<p class="text-muted">Manage all records here with ease.</p>
					<hr style="border: 0; height: 1px; background: #ddd; margin: 10px 0;">
						<ul style="list-style: none; padding: 0; text-align: left;">
							<li style="margin: 10px 0;"><strong>📍 Address:</strong> <span style="color: #555;">Ratna Hospital, Near Vikash Maruti Workshop, Singhana Road, Narnaul, Haryana - 123001</span></li>
							<li style="margin: 10px 0;"><strong>📞 Phone:</strong> <span style="color: #555;">+91-8929545455, 9467305751</span></li>
							<li style="margin: 10px 0;"><strong>📧 Email:</strong> <span style="color: #555;">info@shreeshyammotors.com</span></li>
						</ul>
				<button style="background: #007bff; color: #fff; border: none; padding: 10px 20px; border-radius: 15px; cursor: pointer; transition: 0.3s;">Manage Records</button>
			</div>
        </div>
        <!-- Right Section (Dashboard Cards) -->
        <div class="col-md-7">
			<div class="col-md-12 mb-3"><h3 style="color: #333; font-weight: bold;">Welcome to Search by, <strong><?= htmlspecialchars($_SESSION['username']); ?></strong>!</h3></div>
		<!-- Search Box -->
			<div class="search-box my-3">
				<div class="input-group">
					<input type="text" id="searchBox" class="form-control border-primary shadow-sm" 
						placeholder="🔍 Search by Name, Vehicle, RC No, Mobile, or City..." onkeyup="filterSearch()">
					<button class="btn btn-primary"><i class="fas fa-search"></i></button>
			</div>
				<div id="searchResults" class="list-group mt-2"></div>
			</div>
			
            <div class="row">
    <!-- Purchases -->
    <div class="col-md-6 mb-3">
        <div class="card text-white shadow-lg border-0 animate-card" style="background: linear-gradient(135deg, #28a745, #218838);">
            <div class="card-body text-center">
                <h5 class="card-title"><i class="fas fa-shopping-cart"></i> Total Purchases</h5>
                <p class="fs-2 fw-bold">₹<?= number_format($total_clients_revenue, 2) ?></p>
                <p class="fs-4">Balance: ₹<?= number_format($total_purchase_balance, 2) ?></p>
            </div>
        </div>
    </div>

    <!-- Sales -->
    <div class="col-md-6 mb-3">
        <div class="card text-white shadow-lg border-0 animate-card" style="background: linear-gradient(135deg, #007bff, #0056b3);">
            <div class="card-body text-center">
                <h5 class="card-title"><i class="fas fa-car"></i> Total Sales</h5>
                <p class="fs-2 fw-bold">₹<?= number_format($total_sales_revenue, 2) ?></p>
                <p class="fs-4">Balance: ₹<?= number_format($total_sales_balance, 2) ?></p>
            </div>
        </div>
    </div>

    <!-- Revenue -->
    <div class="col-md-12 mb-3">
        <div class="card text-dark shadow-lg border-0 animate-card" style="background: linear-gradient(135deg, #ffc107, #e0a800);">
            <div class="card-body text-center">
                <h5 class="card-title"><i class="fas fa-coins"></i> Total Revenue</h5>
                <p class="fs-2 fw-bold">₹<?= number_format($total_revenue, 2) ?></p>
                <p class="fs-4">Total Balance: ₹<?= number_format($total_balance_amount_revenue, 2) ?></p>
            </div>
        </div>
    </div>
</div>
        </div>
    </div> 
</div>


    <!-- 📌 Footer -->
    <div class="footer">
        &copy; <?= date("Y"); ?> Shri Shyam Motors | All Rights Reserved
    </div>

    <!-- 🔍 Search Function -->
    <script>
    document.getElementById("searchBox").addEventListener("keyup", function() {
        let query = this.value.trim();
        if (query.length > 1) {
            fetch("search.php?q=" + query)
                .then(response => response.json())
                .then(data => {
                    let results = document.getElementById("searchResults");
                    results.innerHTML = "";
                    data.forEach(item => {
                        let entry = `<a href="${item.url}" class="list-group-item list-group-item-action">
                                        📌 <strong>${item.name}</strong> - ${item.vehicle_name} (RC: ${item.rc_no})<br>
                                        📞 ${item.mobile} | 📍 ${item.city}
                                    </a>`;
                        results.innerHTML += entry;
                    });
                });
        } else {
            document.getElementById("searchResults").innerHTML = "";
        }
    });

    function filterSearch() {
        let input = document.getElementById("searchBox").value.toLowerCase();
        let resultsDiv = document.getElementById("searchResults");
        resultsDiv.innerHTML = "";

        if (input.length > 0) {
            // Simulated search result (replace with AJAX in real case)
            let mockResults = [
                { name: "John Doe", vehicle: "Maruti Swift", rc: "HR26A1234", mobile: "9876543210", city: "Narnaul" },
                { name: "Amit Sharma", vehicle: "Honda City", rc: "HR05B5678", mobile: "9123456780", city: "Mahendergarh" },
                { name: "Pooja Singh", vehicle: "Hyundai i20", rc: "DL01C9876", mobile: "8899001122", city: "Rewari" }
            ];
            
            mockResults.forEach(item => {
                if (
                    item.name.toLowerCase().includes(input) || 
                    item.rc.toLowerCase().includes(input) || 
                    item.mobile.includes(input) || 
                    item.city.toLowerCase().includes(input)
                ) {
                    let element = document.createElement("a");
                    element.href = "#";
                    element.classList.add("list-group-item", "list-group-item-action");
                    element.innerHTML = `📌 <strong>${item.name}</strong> - ${item.vehicle} (RC: ${item.rc})<br>📞 ${item.mobile} | 📍 ${item.city}`;
                    resultsDiv.appendChild(element);
                }
            });
        }
    }
</script>


</body>
</html>

