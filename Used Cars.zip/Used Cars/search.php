<?php
session_start();
require 'db.php'; // Ensure this connects to your database

if (!isset($_GET['q']) || empty($_GET['q'])) {
    echo json_encode([]);
    exit;
}

$search = $conn->real_escape_string($_GET['q']);
$results = [];

// Search in Clients Table
$clients_query = "SELECT id, client_name, vehicle_name, rc_no, mobile FROM clients 
                  WHERE client_name LIKE '%$search%' 
                  OR vehicle_name LIKE '%$search%'
                  OR rc_no LIKE '%$search%'
                  OR mobile LIKE '%$search%'
                  LIMIT 10";
$clients_result = $conn->query($clients_query);

while ($row = $clients_result->fetch_assoc()) {
    $results[] = [
        "name" => $row['client_name'],
        "vehicle_name" => $row['vehicle_name'],
        "rc_no" => $row['rc_no'],
        "url" => "client_details.php?id=" . $row['id'] // Link to Client Details
    ];
}

// Search in Sales Table
$sales_query = "SELECT sale_id, client_name, vehicle_name, rc_no, mobile FROM sales 
                WHERE client_name LIKE '%$search%' 
                OR vehicle_name LIKE '%$search%'
                OR rc_no LIKE '%$search%'
                OR mobile LIKE '%$search%'
                LIMIT 10";
$sales_result = $conn->query($sales_query);

while ($row = $sales_result->fetch_assoc()) {
    $results[] = [
        "name" => $row['client_name'],
        "vehicle_name" => $row['vehicle_name'],
        "rc_no" => $row['rc_no'],
        "url" => "sale_details.php?id=" . $row['sale_id'] // Link to Sale Details
    ];
}

// Return results as JSON
echo json_encode($results);
?>
