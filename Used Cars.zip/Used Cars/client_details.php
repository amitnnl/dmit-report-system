<?php
session_start();
require 'db.php'; // Ensure this connects to your database

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Check if client ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<h2>Error: Client ID is missing.</h2>";
    exit;
}

$client_id = $conn->real_escape_string($_GET['id']);

// Fetch Client Details
$query = "SELECT * FROM clients WHERE id = '$client_id'";
$result = $conn->query($query);

if (!$result || $result->num_rows == 0) {
    echo "<h2>No client found.</h2>";
    exit;
}

$client = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Details | Shri Shyam Motors</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body { background-color: #f8f9fa; }
        .details-container { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); }
        .footer { background-color: #343a40; color: white; text-align: center; padding: 10px 0; margin-top: 20px; }
        .vehicle-photo { max-width: 66%; border-radius: 8px; }
    </style>
</head>
<body>

<!-- 🚗 Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Shri Shyam Motors</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link btn text-white btn-sm" href="index.php">🏠 Dashboard</a></li>
                <li class="nav-item"><a class="nav-link btn text-white btn-sm" href="view_clients.php">📋 Purchase</a></li>
                <li class="nav-item"><a class="nav-link btn text-white btn-sm" href="view_sales.php">🚗 Sales</a></li>
                <li class="nav-item"><a class="nav-link btn text-white btn-sm" href="reports.php">📊 Reports</a></li>
                <li class="nav-item"><a class="nav-link btn text-white btn-sm" href="logout.php">🔒 Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- 📌 Client Details -->
<div class="container mt-4">
    <h2 class="text-center text-primary">👤 Purchase Details</h2>

    <div class="row">
        <!-- Client Info -->
        <div class="col-md-6">
            <div class="details-container">
                <h4 class="text-success">Client Information</h4>
                <p><strong>Name:</strong> <?= htmlspecialchars($client['client_name']) ?></p>
                <p><strong>Mobile:</strong> <?= htmlspecialchars($client['mobile']) ?></p>
                <p><strong>Address:</strong> <?= htmlspecialchars($client['address']) ?>, <?= htmlspecialchars($client['village']) ?></p>
                <p><strong>Purchase Date:</strong> <?= htmlspecialchars($client['purchase_date']) ?></p>
            </div>
			<br>
			<div class="details-container">
                <h4 class="text-danger">💰 Payment Information</h4>
                <p><strong>Paid Amount:</strong> ₹<?= htmlspecialchars($client['paid_amount']) ?></p>
                <p><strong>Balance Amount:</strong> ₹<?= htmlspecialchars($client['balance_amount']) ?></p>
            </div>
        </div>

        <!-- Vehicle Info -->
        <div class="col-md-6">
            <div class="details-container">
                <h4 class="text-primary">🚗 Vehicle Information</h4>
                <p><strong>Vehicle:</strong> <?= htmlspecialchars($client['vehicle_name']) ?></p>
                <p><strong>RC Number:</strong> <?= strtoupper(htmlspecialchars($client['rc_no'])) ?></p>
                <?php if (!empty($client['vehicle_photo'])) { ?>
                    <img src="uploads/<?= htmlspecialchars($client['vehicle_photo']) ?>" class="vehicle-photo" alt="Vehicle Photo">
                <?php } else { ?>
                    <p class="text-muted">No vehicle photo available</p>
                <?php } ?>
            </div>
        </div>
    </div>

    <!-- Payment Info -->
    <div class="row mt-4">
        <div class="col-md-6">
            
        </div>
    </div>

    <!-- Back Button -->
    <div class="text-center mt-3">
        <a href="view_clients.php" class="btn btn-secondary">🔙 Back to Clients</a>
    </div>
</div>

<!-- 📌 Footer -->
<div class="footer">
    &copy; <?= date("Y"); ?> Shri Shyam Motors | All Rights Reserved
</div>

</body>
</html>
