<?php
include ("db.php"); // Ensure database connection

if (!isset($_GET['sale_id']) || !is_numeric($_GET['sale_id'])) {
    die("<p class='text-danger text-center'>⚠️ Error: Valid Sale ID is required.</p>");
}

$sale_id = intval($_GET['sale_id']); 
$sql = "SELECT * FROM sales WHERE sale_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $sale_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("<p class='text-danger text-center'>⚠️ Error: Sale record not found.</p>");
}

$sale = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Sale</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
	<style>
	body { display: flex; flex-direction: column; min-height: 100vh; margin: 0; }
	.container { flex: 1; margin-bottom: 20px; /* Adds space between content and footer */ }
	.footer { background: #343a40; color: white; text-align: center; padding: 10px 0; width: 100%; }
    </style>
	
</head>
<body>
<!-- 🚗 Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Shri Shyam Motors</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">🏠 Dashboard</a></li>

                <!-- Purchase Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="purchaseDropdown" role="button" data-bs-toggle="dropdown">
                        📋 Purchase
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="purchaseDropdown">
                        <li><a class="dropdown-item" href="client_form.php">➕ Add Purchase</a></li>
                        <li><a class="dropdown-item" href="view_clients.php">📜 Purchase History</a></li>
                    </ul>
                </li>

                <!-- Sales Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="salesDropdown" role="button" data-bs-toggle="dropdown">
                        🚗 Sales
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="salesDropdown">
                        <li><a class="dropdown-item" href="sales_form.php">➕ Add Sale</a></li>
                        <li><a class="dropdown-item" href="view_sales.php">📜 Sales History</a></li>
                    </ul>
                </li>

                <li class="nav-item"><a class="nav-link" href="reports.php">📊 Reports</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">🔒 Logout</a></li>
            </ul>
        </div>
    </div>
</nav>
<div class="container mt-5">
    
    <form action="process_sales.php" method="POST" enctype="multipart/form-data" class="p-4 shadow-lg bg-white rounded-3">
        <input type="hidden" name="sale_id" value="<?= htmlspecialchars($sale['sale_id']) ?>">
        <div class="row g-4">
          <h2 class="text-center mb-4 text-primary fw-bold">Edit Sale Record</h2>
			<div class="col-md-6">
			  <h4 class="text-center mb-3 text-secondary">Client Information</h4>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Client Name</label>
                    <input type="text" name="client_name" class="form-control border-2" value="<?= htmlspecialchars($sale['client_name']) ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Mobile</label>
                    <input type="text" name="mobile" class="form-control border-2" value="<?= htmlspecialchars($sale['mobile']) ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Address</label>
                    <textarea name="address" class="form-control border-2" required><?= htmlspecialchars($sale['address']) ?></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Village/Town/City</label>
                    <input type="text" name="village" class="form-control border-2" value="<?= htmlspecialchars($sale['village']) ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Sale Date</label>
                    <input type="date" name="sale_date" class="form-control border-2" value="<?= htmlspecialchars($sale['sale_date']) ?>" required>
                </div>
            </div>

            <div class="col-md-6">
			  <h4 class="text-center mb-3 text-secondary">Vehicle Details</h4>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Vehicle Name</label>
                    <input type="text" name="vehicle_name" class="form-control border-2" value="<?= htmlspecialchars($sale['vehicle_name']) ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Vehicle RC No.</label>
                    <input type="text" name="rc_no" class="form-control border-2" value="<?= htmlspecialchars($sale['rc_no']) ?>" required style="text-transform: uppercase;">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Vehicle Price</label>
                    <input type="number" id="vehicle_price" name="vehicle_price" class="form-control border-2" min="0" step="0.01" value="<?= htmlspecialchars($sale['vehicle_price']) ?>" required oninput="calculateBalance()">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Paid Amount</label>
                    <input type="number" id="paid_amount" name="paid_amount" class="form-control border-2" min="0" step="0.01" value="<?= htmlspecialchars($sale['paid_amount']) ?>" required oninput="calculateBalance()">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Balance Amount</label>
                    <input type="number" id="balance_amount" name="balance_amount" class="form-control border-2 bg-light" value="<?= htmlspecialchars($sale['balance_amount']) ?>" readonly>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Vehicle Photo</label>
                    <input type="file" name="vehicle_photo" class="form-control border-2" accept="image/*">
                    <?php if (!empty($sale['vehicle_photo'])): ?>
                        <div class="mt-2">
                            <img src="uploads/<?= htmlspecialchars($sale['vehicle_photo']) ?>" class="img-thumbnail rounded shadow-sm" width="120" alt="Vehicle Photo">
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="text-center">
            <button type="submit" class="btn btn-success px-5 py-2 fw-semibold shadow-sm">Update Sale</button>
        </div>
    </form>
</div>

    <script>
	function fetchVehicleDetails(rc_no) {
    if (rc_no === "") {
        document.getElementById("vehicle_name").value = "";
        document.getElementById("vehicle_photo_preview").innerHTML = "";
        return;
    }

    fetch("sales_form.php?rc_no=" + rc_no)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                console.error(data.error);
                return;
            }
            document.getElementById("vehicle_name").value = data.vehicle_name || "N/A";
            if (data.vehicle_photo) {
                document.getElementById("vehicle_photo_preview").innerHTML = `<img src='uploads/${data.vehicle_photo}' width='150' class='img-thumbnail'>`;
            } else {
                document.getElementById("vehicle_photo_preview").innerHTML = "";
            }
        })
        .catch(error => console.error("Error fetching data:", error));
}

        function calculateBalance() {
            let vehiclePrice = parseFloat(document.getElementById("vehicle_price").value) || 0;
            let paidAmount = parseFloat(document.getElementById("paid_amount").value) || 0;
            let balanceAmount = vehiclePrice - paidAmount;
            document.getElementById("balance_amount").value = balanceAmount.toFixed(2);
        }
    </script>
	 <!-- 📌 Footer -->
    <div class="footer">
        &copy; <?= date("Y"); ?> Shri Shyam Motors | All Rights Reserved
    </div>
</body>
</html>
