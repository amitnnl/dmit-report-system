<?php
include ("db.php"); // Ensure database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0; // Get ID for update

    $client_name = $_POST['client_name'];
    $mobile = $_POST['mobile'];
    $address = $_POST['address'];
    $village = $_POST['village'];
    $purchase_date = $_POST['purchase_date'];  // ✅ Correct field name
    $vehicle_name = $_POST['vehicle_name'];
    $rc_no = $_POST['rc_no'];
    $vehicle_price = $_POST['vehicle_price'];  // ✅ Correct field name
    $paid_amount = $_POST['paid_amount'];
    $balance_amount = $_POST['balance_amount'];

    // Handle file upload
    $vehicle_photo = "";
    if (!empty($_FILES["vehicle_photo"]["name"])) {
        $target_dir = "uploads/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $vehicle_photo = basename($_FILES["vehicle_photo"]["name"]);
        move_uploaded_file($_FILES["vehicle_photo"]["tmp_name"], $target_dir . $vehicle_photo);
    }

    if ($id > 0) {
        // ✅ **Update Existing Client**
        if (!empty($vehicle_photo)) {
            $sql = "UPDATE clients SET client_name=?, mobile=?, address=?, village=?, purchase_date=?, vehicle_name=?, rc_no=?, vehicle_price=?, paid_amount=?, balance_amount=?, vehicle_photo=? WHERE id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssssssssssi", $client_name, $mobile, $address, $village, $purchase_date, $vehicle_name, $rc_no, $vehicle_price, $paid_amount, $balance_amount, $vehicle_photo, $id);
        } else {
            $sql = "UPDATE clients SET client_name=?, mobile=?, address=?, village=?, purchase_date=?, vehicle_name=?, rc_no=?, vehicle_price=?, paid_amount=?, balance_amount=? WHERE id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssssssi", $client_name, $mobile, $address, $village, $purchase_date, $vehicle_name, $rc_no, $vehicle_price, $paid_amount, $balance_amount, $id);
        }
    } else {
        // ✅ **Insert New Client**
        $sql = "INSERT INTO clients (client_name, mobile, address, village, purchase_date, vehicle_name, rc_no, vehicle_price, paid_amount, balance_amount, vehicle_photo) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssssssss", $client_name, $mobile, $address, $village, $purchase_date, $vehicle_name, $rc_no, $vehicle_price, $paid_amount, $balance_amount, $vehicle_photo);
    }

    if ($stmt->execute()) {
        header("Location: view_clients.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
