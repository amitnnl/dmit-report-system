<?php
session_start();
require 'db.php'; // Ensure this connects to your database

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Check if sale ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<h2>Error: Sale ID is missing.</h2>";
    exit;
}

$sale_id = $conn->real_escape_string($_GET['id']);

// Fetch Sale Details
$query = "SELECT * FROM sales WHERE sale_id = '$sale_id'";
$result = $conn->query($query);

if (!$result || $result->num_rows == 0) {
    echo "<h2>No sale record found.</h2>";
    exit;
}

$sale = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sale Details | Shri Shyam Motors</title>
    <link href="bootstrap-5.0.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="bootstrap-5.0.2/js/bootstrap.bundle.min.js"></script>
	<style>
        body { background-color: #f8f9fa; }
        .details-container { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); }
        .footer { background-color: #343a40; color: white; text-align: center; padding: 10px 0; margin-top: 20px; }
        .vehicle-photo { max-width: 60%; border-radius: 8px; }
    </style>
</head>
<body>

<!-- 🚗 Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Shri Shyam Motors</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link btn text-white btn-sm" href="index.php">🏠 Dashboard</a></li>
                <li class="nav-item"><a class="nav-link btn text-white btn-sm" href="view_clients.php">📋 Purchases</a></li>
                <li class="nav-item"><a class="nav-link btn text-white btn-sm" href="view_sales.php">🚗 Sales</a></li>
                <li class="nav-item"><a class="nav-link btn text-white btn-sm" href="reports.php">📊 Reports</a></li>
                <li class="nav-item"><a class="nav-link btn text-white btn-sm" href="logout.php">🔒 Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- 📌 Sale Details -->
<div class="container mt-5">
    <h2 class="text-center text-success mb-4">🚗 Sale Details</h2>

    <div class="row">
        <!-- Client Info -->
        <div class="col-md-6 mb-4">
            <div class="bg-white p-4 rounded shadow-sm">
                <h4 class="text-primary">👤 Client Information</h4>
                <p><strong>Name:</strong> <?= htmlspecialchars($sale['client_name']) ?></p>
                <p><strong>Mobile:</strong> <?= htmlspecialchars($sale['mobile']) ?></p>
                <p><strong>Sale Date:</strong> <?= htmlspecialchars($sale['sale_date']) ?></p>
            </div>
			<div class="bg-white p-4 rounded shadow-sm">
                <h4 class="text-warning">💰 Payment Information</h4>
                <p><strong>Paid Amount:</strong> ₹<?= htmlspecialchars($sale['paid_amount']) ?></p>
                <p><strong>Balance Amount:</strong> ₹<?= htmlspecialchars($sale['balance_amount']) ?></p>
            </div>
        </div>

        <!-- Vehicle Info -->
        <div class="col-md-6 mb-4">
            <div class="bg-white p-4 rounded shadow-sm">
                <h4 class="text-danger">🚗 Vehicle Information</h4>
                <p><strong>Vehicle Name:</strong> <?= htmlspecialchars($sale['vehicle_name']) ?></p>
                <p><strong>RC Number:</strong> <?= strtoupper(htmlspecialchars($sale['rc_no'])) ?></p>
                <?php if (!empty($sale['vehicle_photo'])) { ?>
                    <img src="uploads/<?= htmlspecialchars($sale['vehicle_photo']) ?>" class="vehicle-photo" alt="Vehicle Photo">
                <?php } else { ?>
                    <p class="text-muted">No vehicle photo available</p>
                <?php } ?>
            </div>
        </div>
    </div>

    <!-- Payment Info -->
    <div class="row mt-4">
        <div class="col-md-6 mb-4">
            
        </div>
    </div>

    <!-- Back Button -->
    <div class="text-center mt-4">
        <a href="view_sales.php" class="btn btn-secondary btn-lg">🔙 Back to Sales</a>
    </div>
</div>

<!-- 📌 Footer -->
<div class="bg-dark text-white text-center py-3 mt-5">
    &copy; <?= date("Y"); ?> Shri Shyam Motors | All Rights Reserved
</div>

</body>
</html>
