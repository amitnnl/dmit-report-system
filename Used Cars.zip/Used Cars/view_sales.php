<?php
include ("db.php"); // Ensure database connection

$sql = "SELECT * FROM sales ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body .container { max-width: 90%; }
        .table { background-color: #fff; border-radius: 10px; overflow: hidden; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); }
        .table th { background-color: #007bff; color: white; text-align: center; cursor: pointer; }
        .table td { text-align: center; vertical-align: middle; }
        .search-box { width: 50%; margin: 10px auto; }
        .footer { background-color: #343a40; color: white; text-align: center; padding: 10px 0; position: fixed; bottom: 0; width: 100%; }
    </style>
</head>
<body>
<!-- 🚗 Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Shri Shyam Motors</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">🏠 Dashboard</a></li>

                <!-- Purchase Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="purchaseDropdown" role="button" data-bs-toggle="dropdown">
                        📋 Purchase
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="purchaseDropdown">
                        <li><a class="dropdown-item" href="client_form.php">➕ Add Purchase</a></li>
                        <li><a class="dropdown-item" href="view_clients.php">📜 Purchase History</a></li>
                    </ul>
                </li>

                <!-- Sales Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="salesDropdown" role="button" data-bs-toggle="dropdown">
                        🚗 Sales
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="salesDropdown">
                        <li><a class="dropdown-item" href="sales_form.php">➕ Add Sale</a></li>
                        <li><a class="dropdown-item" href="view_sales.php">📜 Sales History</a></li>
                    </ul>
                </li>

                <li class="nav-item"><a class="nav-link" href="reports.php">📊 Reports</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">🔒 Logout</a></li>
            </ul>
        </div>
    </div>
</nav>
<div class="container mt-4">   
    <!-- Search Box -->
    <div class="mb-4">
    <h2 class="text-center mb-4 text-primary">📋 Sales Records</h2>
    <div class="d-flex align-items-center justify-content-between">
        <a href="export_records.php?type=sales" class="btn btn-success btn-sm px-2">⬇️ Export Sales</a>
        <div class="input-group w-50">
            <span class="input-group-text bg-primary text-white">🔍</span>
            <input type="text" id="search" class="form-control border-primary shadow-sm" placeholder="Search by Name, Mobile, or Vehicle...">
        </div>
    </div>
</div>


    <!-- Table -->
    <div class="table-responsive mt-3">
        <table class="table table-bordered table-hover table-striped shadow-sm">
            <thead class="table-dark text-center">
                <tr>
                    <th>Sale ID</th>
                    <th>Name</th>
                    <th>Mobile</th>
                    <th>Vehicle</th>
                    <th>Reg. No.</th>
                    <th>Sale Date</th>
                    <th>Price</th>
                    <th>Paid</th>
                    <th>Balance</th>
                    <th>Photo</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="salesTable">
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr id="row-<?= $row['sale_id'] ?>" class="align-middle">
                        <td class="text-center"><?= htmlspecialchars($row["sale_id"]) ?></td>
                        <td><?= htmlspecialchars($row["client_name"]) ?></td>
                        <td><?= htmlspecialchars($row["mobile"]) ?></td>
                        <td><?= htmlspecialchars($row["vehicle_name"]) ?></td>
                        <td><?= htmlspecialchars(strtoupper($row["rc_no"])) ?></td>
                        <td><?= htmlspecialchars($row["sale_date"]) ?></td>
                        <td class="text-end">₹<?= number_format($row["vehicle_price"], 2) ?></td>
                        <td class="text-end">₹<?= number_format($row["paid_amount"], 2) ?></td>
                        <td class="text-end fw-bold">₹<?= number_format($row["balance_amount"], 2) ?></td>
                        <td class="text-center">
                            <?php if (!empty($row["vehicle_photo"])) { ?>
                                <img src="uploads/<?= htmlspecialchars($row["vehicle_photo"]) ?>" class="rounded shadow-sm" width="80" alt="Vehicle Photo">
                            <?php } else { echo "No Image"; } ?>
                        </td>
                        <td class="text-center">
                            <button class="btn btn-warning btn-sm px-2" onclick="editSale(<?= $row['sale_id'] ?>)">✏️ Edit</button>
                            <button class="btn btn-danger btn-sm px-2" onclick="deleteSale(<?= $row['sale_id'] ?>)">🗑️ Delete</button>
                            <button class="btn btn-success btn-sm px-2" onclick="printSale(<?= $row['sale_id'] ?>)">🖨️ Print</button>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

    
    <script>
        document.getElementById("search").addEventListener("keyup", function () {
            let searchValue = this.value.toLowerCase();
            document.querySelectorAll("#salesTable tr").forEach(row => {
                let match = [...row.cells].some(cell => cell.textContent.toLowerCase().includes(searchValue));
                row.style.display = match ? "" : "none";
            });
        });

        function editSale(sale_id) {
            window.location.href = "edit_sales.php?sale_id=" + sale_id;
        }

        function deleteSale(sale_id) {
            Swal.fire({
                title: "Are you sure?",
                text: "This will permanently delete the record!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "Yes, Delete!",
                cancelButtonText: "Cancel",
                confirmButtonColor: "#d33",
                cancelButtonColor: "#3085d6"
            }).then(result => {
                if (result.isConfirmed) {
                    fetch("delete_sales.php?sale_id=" + sale_id, { method: "GET" })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                document.getElementById("row-" + sale_id).remove();
                                Swal.fire("Deleted!", "Sales record has been deleted.", "success");
                            } else {
                                Swal.fire("Error!", "Failed to delete record.", "error");
                            }
                        })
                        .catch(() => Swal.fire("Error!", "Something went wrong.", "error"));
                }
            });
        }

        function printSale(sale_id) {
    let row = document.getElementById("row-" + sale_id);
    if (!row) {
        Swal.fire("Error!", "Sale not found!", "error");
        return;
    }

    let photoSrc = row.cells[9].querySelector("img") ? row.cells[9].querySelector("img").src : "";

    // Get current date and time
    let now = new Date();
    let printDate = now.toLocaleDateString();
    let printTime = now.toLocaleTimeString();

    let content = `
        <html>
        <head>
            <title>Invoice - Shri Shyam Motors</title>
            <style>
                body { font-family: 'Arial', sans-serif; background: #f8f9fa; padding: 20px; }
                .invoice-container { width: 80%; margin: auto; padding: 25px; border: 2px solid #000; background: #fff; border-radius: 10px; }
                .header { text-align: center; padding-bottom: 5px; border-bottom: 2px solid #000; position: relative; }
                .header img { width: 120px; margin-bottom: 5px; }
                .header h3 { margin: 5px 0; color: #007bff; font-size: 20px; }
                .company-details { text-align: center; font-size: 14px; color: #555; }
                .invoice-title { text-align: center; font-size: 22px; font-weight: bold; margin-top: 15px; text-decoration: underline; }
                .date-time { position: absolute; top: 10px; right: 15px; font-size: 14px; color: #555; }
                .details-container { display: flex; justify-content: space-between; margin-top: 20px; padding: 15px; border: 1px solid #000; border-radius: 8px; background: #f4f4f4; }
                .left-section, .right-section { width: 48%; }
                .left-section p, .right-section p { font-size: 16px; font-weight: bold; margin: 8px 0; }
                .photo { width: 180px; display: block; margin: 15px auto; border-radius: 10px; border: 1px solid #000; }
                .footer { margin-top: 20px; text-align: center; font-size: 14px; font-style: italic; border-top: 2px solid #000; padding-top: 10px; }
                .signature { margin-top: 40px; text-align: right; padding-right: 40px; font-weight: bold; }
                .signature img { width: 120px; }
            </style>
        </head>
        <body>
            <div class="invoice-container">
                <div class="header">
                    <img src="uploads/logo01.png" alt="Company Logo">
                    <h3 class="company-details"> Old Car Sales & Purchase </h3>
                    <p class="company-details"> Address: Ratna Hospital, 
                        Near Vikash Maruti Workshop, Singhana Road, Narnaul, Haryana - 123001 <br>
                        Contact: +91-8929545455, 9467305751 | Email: info@shreeshyammotors.com
                    </p>
                    <div class="date-time">
                        <b>Print Date:</b> ${printDate} <br>
                        <b>Time:</b> ${printTime}
                    </div>
                </div>
                
                <h3 class="invoice-title">Sale Invoice</h3>
                
                <div class="details-container">
                    <div class="left-section">
                        <p><b>Client ID:</b> ${row.cells[0].textContent.trim()}</p>
                        <p><b>Name:</b> ${row.cells[1].textContent.trim()}</p>
                        <p><b>Mobile:</b> ${row.cells[2].textContent.trim()}</p>
                        <p><b>Vehicle:</b> ${row.cells[3].textContent.trim()}</p>
                        <p><b>Reg. No.</b> ${row.cells[4].textContent.trim()}</p>
                    </div>
                    <div class="right-section">
                        <p><b>Sale Date:</b> ${row.cells[5].textContent.trim()}</p>
                        <p><b>Price:</b> ${row.cells[6].textContent.trim()}</p>
                        <p><b>Paid:</b> ${row.cells[7].textContent.trim()}</p>
                        <p><b>Balance Amount:</b> ₹${row.cells[8].textContent.trim()}</p>
                    </div>
					${photoSrc ? `<img src="${photoSrc}" class="photo" alt="Vehicle Photo">` : ""}
                </div>

                <div class="signature">
                    <p>Authorized Signature</p>
                    <img src="stamp_or_signature.png" alt="Company Stamp/Signature">
                </div>

                <div class="footer">
                    <p>Thank you for your business!</p>
                    <p>For any queries, contact us at Shri Shyam Motors</p>
                </div>
            </div>
        </body>
        </html>
    `;

    let printWindow = window.open("", "_blank");
    printWindow.document.write(content);
    printWindow.document.close();
    printWindow.onload = () => printWindow.print();
}
    
    // Search Functionality
    function searchSales() {
        const searchQuery = document.getElementById('search').value.toLowerCase();

        // Fetch the data from the server using AJAX
        const xhr = new XMLHttpRequest();
        xhr.open('GET', 'search_sales.php?query=' + searchQuery, true);
        xhr.onload = function () {
            if (xhr.status === 200) {
                // Update the table with the search results
                document.getElementById('sales-records-table').innerHTML = xhr.responseText;
            } else {
                console.error('Error loading sales records.');
            }
        };
        xhr.send();
    }
</script>
	 <!-- 📌 Footer -->
    <div class="footer">
        &copy; <?= date("Y"); ?> Shri Shyam Motors | All Rights Reserved
    </div>
</body>
</html>

<?php $conn->close(); ?>
