<?php
session_start();
include "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = sha1($_POST['password']);

    $sql = "SELECT * FROM users WHERE username=? AND password=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $_SESSION['username'] = $username;
        header("Location: index.php");
        exit;
    } else {
        $error = "Invalid Username or Password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Shri Shyam Motors</title>
    <link href="bootstrap-5.0.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to right, #6a11cb, #2575fc);
            height: 70vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-box {
            max-width: 900px;
            background: #fff;
            border-radius: 15px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.2);
            overflow: hidden;
            display: flex;
            flex-direction: row;
        }
        .left-side {
            background: #f8f9fa;
            padding: 40px;
            text-align: center;
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        .right-side {
            padding: 40px;
            flex: 1;
        }
        .logo {
            max-width: 120px;
            margin-bottom: 15px;
        }
        .btn-primary {
            background: #2575fc;
            border: none;
        }
        .btn-primary:hover {
            background: #1b5ed4;
        }
    </style>
</head>
<body>

<div class="login-box">

    <!-- Left Side: Company Info -->
    <div class="left-side">
        <!-- 🚗 Company Logo -->
        <img src="uploads/logo01.png" alt="Shri Shyam Motors Logo" class="img-fluid" style="max-width: 180px; border-radius: 50%;">

        <!-- 🏠 Company Name & Info -->  
        <p><strong>Address:</strong> Ratna Hospital, Near Vikash Maruti Workshop, Singhana Road, Narnaul,<br> Haryana - 123001</p>
        <p><strong>Phone:</strong> +91-8929545455, 9467305751 <br> <strong>Email:</strong> info@shreeshyammotors.com</p>
    </div>

    <!-- Right Side: Login Form -->
    <div class="right-side">
        <h3 class="text-start">🔑 Login</h3>

        <!-- Error Message Display -->
        <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Username</label>
                <input type="text" name="username" class="form-control" placeholder="Enter your username" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
            </div>

            <button type="submit" class="btn btn-primary w-100">Login</button>
        </form>
    </div>

</div>

<script src="bootstrap-5.0.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
