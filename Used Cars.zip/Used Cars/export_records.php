<?php
include "db.php"; // Ensure database connection

$type = isset($_GET['type']) ? $_GET['type'] : '';

if ($type == 'purchase') {
    $filename = "purchase_list.xls";
    $sql = "SELECT * FROM clients ORDER BY created_at DESC";
    $header = "Client ID\tClient Name\tMobile\tVehicle\tReg. No.\tPurchase Date\tPrice\tPaid\tBalance\n";
} elseif ($type == 'sales') {
    $filename = "sales_list.xls";
    // Ensure column names are correct in the sales table
    $sql = "SELECT sale_id, client_name, mobile, vehicle_name, rc_no, sale_date, vehicle_price, paid_amount, balance_amount FROM sales ORDER BY created_at DESC";
    $header = "Sale ID\tClient Name\tMobile\tVehicle\tReg. No.\tSale Date\tPrice\tPaid\tBalance\n";
} else {
    die("Invalid export type!");
}

// Set headers for Excel download
header('Content-Type: application/vnd.ms-excel');
header("Content-Disposition: attachment; filename=\"$filename\"");

// Print column headers
echo $header;

$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
    echo htmlspecialchars($row["sale_id"] ?? $row["id"]) . "\t" . 
         htmlspecialchars($row["client_name"] ?? '') . "\t" . 
         htmlspecialchars($row["mobile"] ?? '') . "\t" . 
         htmlspecialchars($row["vehicle_name"] ?? '') . "\t" . 
         htmlspecialchars($row["rc_no"] ?? '') . "\t" . 
         htmlspecialchars($row["sale_date"] ?? '') . "\t" . 
         htmlspecialchars($row["vehicle_price"] ?? '') . "\t" . 
         htmlspecialchars($row["paid_amount"] ?? '') . "\t₹" . 
         number_format($row["balance_amount"] ?? 0, 2) . "\n";
}
exit;
?>
