<!-- 🚗 Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Shri Shyam Motors</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">🏠 Dashboard</a></li>

                <!-- Purchase Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="purchaseDropdown" role="button" data-bs-toggle="dropdown">
                        📋 Purchase
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="purchaseDropdown">
                        <li><a class="dropdown-item" href="client_form.php">➕ Add Purchase</a></li>
                        <li><a class="dropdown-item" href="view_clients.php">📜 Purchase History</a></li>
                    </ul>
                </li>

                <!-- Sales Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="salesDropdown" role="button" data-bs-toggle="dropdown">
                        🚗 Sales
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="salesDropdown">
                        <li><a class="dropdown-item" href="sales_form.php">➕ Add Sale</a></li>
                        <li><a class="dropdown-item" href="view_sales.php">📜 Sales History</a></li>
                    </ul>
                </li>

                <li class="nav-item"><a class="nav-link" href="reports.php">📊 Reports</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">🔒 Logout</a></li>
            </ul>
        </div>
    </div>
</nav>