<?php
include("db.php"); // Ensure database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $sale_id = isset($_POST['sale_id']) && !empty($_POST['sale_id']) ? intval($_POST['sale_id']) : null;
    $client_name = trim($_POST['client_name']);
    $mobile = trim($_POST['mobile']);
    $address = trim($_POST['address']);
    $village = trim($_POST['village']);
    $sale_date = $_POST['sale_date'];
    $vehicle_name = trim($_POST['vehicle_name']);
    $rc_no = trim($_POST['rc_no']);
    $vehicle_price = floatval($_POST['vehicle_price']);
    $paid_amount = floatval($_POST['paid_amount']);
    $balance_amount = $vehicle_price - $paid_amount;

    // ✅ Ensure the "uploads" directory exists
    $target_dir = "uploads/";
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $file_name = ""; // Default empty file name

    // ✅ Fetch existing vehicle photo from clients table if available
    $sql = "SELECT vehicle_photo FROM clients WHERE rc_no = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $rc_no);
    $stmt->execute();
    $result = $stmt->get_result();
    $clientData = $result->fetch_assoc();
    $existing_client_photo = !empty($clientData['vehicle_photo']) ? $clientData['vehicle_photo'] : "";

    // ✅ Handling file upload (if a new one is provided)
    if (!empty($_FILES['vehicle_photo']['name'])) {
        $original_filename = basename($_FILES["vehicle_photo"]["name"]);
        $file_name = time() . "_" . preg_replace("/[^a-zA-Z0-9.]/", "_", $original_filename); // Rename file safely
        $target_file = $target_dir . $file_name;
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // ✅ Validate file type (only allow images)
        $allowed_types = ["jpg", "jpeg", "png", "gif"];
        if (!in_array($file_type, $allowed_types)) {
            die("<p class='text-danger text-center'>⚠️ Error: Only JPG, JPEG, PNG, and GIF files are allowed.</p>");
        }

        // ✅ Move uploaded file
        if (!move_uploaded_file($_FILES["vehicle_photo"]["tmp_name"], $target_file)) {
            die("<p class='text-danger text-center'>⚠️ Error uploading vehicle photo.</p>");
        }
    } else {
        // ✅ Use existing client photo if no new one is uploaded
        $file_name = $existing_client_photo;
    }

    // **Check if Updating or Inserting New Sale**
    if ($sale_id) {
        // ✅ Fetch existing record to keep old photo if no new one is uploaded
        $sql = "SELECT vehicle_photo FROM sales WHERE sale_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $sale_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $existingData = $result->fetch_assoc();
        $existing_sale_photo = $existingData['vehicle_photo'];

        // ✅ If no new file is uploaded, keep the old one from sales or clients
        if (empty($file_name)) {
            $file_name = !empty($existing_sale_photo) ? $existing_sale_photo : $existing_client_photo;
        }

        // **UPDATE SALE RECORD**
        $sql = "UPDATE sales SET 
                    client_name=?, mobile=?, address=?, village=?, sale_date=?, 
                    vehicle_name=?, rc_no=?, vehicle_price=?, paid_amount=?, balance_amount=?, vehicle_photo=? 
                WHERE sale_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssssddssi", 
            $client_name, $mobile, $address, $village, $sale_date, 
            $vehicle_name, $rc_no, $vehicle_price, $paid_amount, 
            $balance_amount, $file_name, $sale_id
        );

        if ($stmt->execute()) {
            echo "<script>alert('Sale updated successfully!'); window.location.href='view_sales.php';</script>";
        } else {
            echo "<p class='text-danger text-center'>⚠️ Error updating record: " . $conn->error . "</p>";
        }
    } else {
        // **INSERT NEW SALE**
        $sql = "INSERT INTO sales (client_name, mobile, address, village, sale_date, vehicle_name, rc_no, vehicle_price, paid_amount, balance_amount, vehicle_photo) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssssddss", 
            $client_name, $mobile, $address, $village, $sale_date, 
            $vehicle_name, $rc_no, $vehicle_price, $paid_amount, 
            $balance_amount, $file_name
        );

        if ($stmt->execute()) {
            echo "<script>alert('New sale added successfully!'); window.location.href='view_sales.php';</script>";
        } else {
            echo "<p class='text-danger text-center'>⚠️ Error saving new sale: " . $conn->error . "</p>";
        }
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>
