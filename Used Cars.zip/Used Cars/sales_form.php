<?php
include("db.php");

if (isset($_GET['rc_no'])) {
    $rc_no = $_GET['rc_no'];

    $sql = "SELECT vehicle_name, vehicle_photo FROM clients WHERE rc_no = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $rc_no);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $row['vehicle_photo'] = !empty($row['vehicle_photo']) ? "uploads/" . $row['vehicle_photo'] : "";
        echo json_encode($row);
    } else {
        echo json_encode(["error" => "No data found for RC No: $rc_no"]);
    }

    $stmt->close();
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Sale</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
<!-- 🚗 Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Shri Shyam Motors</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">🏠 Dashboard</a></li>

                <!-- Purchase Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="purchaseDropdown" role="button" data-bs-toggle="dropdown">
                        📋 Purchase
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="purchaseDropdown">
                        <li><a class="dropdown-item" href="client_form.php">➕ Add Purchase</a></li>
                        <li><a class="dropdown-item" href="view_clients.php">📜 Purchase History</a></li>
                    </ul>
                </li>

                <!-- Sales Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="salesDropdown" role="button" data-bs-toggle="dropdown">
                        🚗 Sales
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="salesDropdown">
                        <li><a class="dropdown-item" href="sales_form.php">➕ Add Sale</a></li>
                        <li><a class="dropdown-item" href="view_sales.php">📜 Sales History</a></li>
                    </ul>
                </li>

                <li class="nav-item"><a class="nav-link" href="reports.php">📊 Reports</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">🔒 Logout</a></li>
            </ul>
        </div>
    </div>
</nav>
<div class="container mt-5 mb-5">
    <form action="process_sales.php" method="POST" enctype="multipart/form-data" class="p-4 shadow-lg bg-white rounded-3">
        <h2 class="text-center mb-4 text-primary fw-bold">Add Sale Record</h2>
			<input type="hidden" name="sale_id" value="0">
		<div class="row g-4">
            <div class="col-md-6">
                <h4 class="text-secondary fw-semibold">Client Information</h4>
                <label class="form-label">Client Name</label>
                <input type="text" name="client_name" class="form-control" required>
                <label class="form-label">Mobile</label>
                <input type="text" name="mobile" class="form-control" required>
                <label class="form-label">Address</label>
                <textarea name="address" class="form-control" required></textarea>
				<label class="form-label">City/Town/village</label>
				<input type="text" name="village" class="form-control border-2" required>
                <label class="form-label">Sale Date</label>
                <input type="date" name="sale_date" class="form-control" required>
            </div>
            <div class="col-md-6">
    <h4 class="text-secondary fw-semibold">Vehicle Details</h4>
    <label class="form-label">Vehicle RC No.</label>
    <select id="rc_no" name="rc_no" class="form-control" required onchange="fetchVehicleDetails(this.value)" style="text-transform: uppercase">
        <option value="">Select RC No.</option>
        <?php 
        $sql = "SELECT rc_no FROM clients";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            echo "<option value='".$row['rc_no']."'>".$row['rc_no']."</option>";
        }
        ?>
    </select>
    <label class="form-label">Vehicle Name</label>
    <input type="text" id="vehicle_name" name="vehicle_name" class="form-control bg-light" readonly>
    <label class="form-label">Vehicle Price</label>
    <input type="number" id="vehicle_price" name="vehicle_price" class="form-control" required oninput="calculateBalance()">
    <label class="form-label">Paid Amount</label>
    <input type="number" id="paid_amount" name="paid_amount" class="form-control" required oninput="calculateBalance()">
    <label class="form-label">Balance Amount</label>
    <input type="number" id="balance_amount" name="balance_amount" class="form-control bg-light" readonly>
    <label class="form-label">Vehicle Photo</label>
    <input type="hidden" id="vehicle_photo" name="vehicle_photo" class="form-control">
    <div id="vehicle_photo_preview"></div>
</div>
        </div>
		<br>
        <div class="text-center">
            <button type="submit" class="btn btn-primary px-5 py-2">Add Sale</button>
        </div>
    </form>
</div>
<script>
function fetchVehicleDetails(rc_no) {
    if (rc_no === "") {
        document.getElementById("vehicle_name").value = "";
        document.getElementById("vehicle_photo").value = "";
        document.getElementById("vehicle_photo_preview").innerHTML = "";
        return;
    }

    fetch("sales_form.php?rc_no=" + rc_no)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                console.error(data.error);
                return;
            }

            document.getElementById("vehicle_name").value = data.vehicle_name || "N/A";
            document.getElementById("vehicle_photo").value = data.vehicle_photo; // ✅ Correctly setting hidden input value

            if (data.vehicle_photo) {
                document.getElementById("vehicle_photo_preview").innerHTML = 
                    `<img src='${data.vehicle_photo}' width='150' class='img-thumbnail'>`;
            } else {
                document.getElementById("vehicle_photo_preview").innerHTML = "";
            }
        })
        .catch(error => console.error("Error fetching data:", error));
}

function calculateBalance() {
    let price = parseFloat(document.getElementById('vehicle_price').value) || 0;
    let paid = parseFloat(document.getElementById('paid_amount').value) || 0;
    document.getElementById('balance_amount').value = (price - paid).toFixed(2);
}
</script>
<div class="footer text-center bg-dark text-white py-3">&copy; <?= date("Y"); ?> Shri Shyam Motors | All Rights Reserved</div>
</body>
</html>
