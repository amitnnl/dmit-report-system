<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Information Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<!-- 🚗 Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Shri Shyam Motors</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">🏠 Dashboard</a></li>

                <!-- Purchase Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="purchaseDropdown" role="button" data-bs-toggle="dropdown">
                        📋 Purchase
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="purchaseDropdown">
                        <li><a class="dropdown-item" href="client_form.php">➕ Add Purchase</a></li>
                        <li><a class="dropdown-item" href="view_clients.php">📜 Purchase History</a></li>
                    </ul>
                </li>

                <!-- Sales Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="salesDropdown" role="button" data-bs-toggle="dropdown">
                        🚗 Sales
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="salesDropdown">
                        <li><a class="dropdown-item" href="sales_form.php">➕ Add Sale</a></li>
                        <li><a class="dropdown-item" href="view_sales.php">📜 Sales History</a></li>
                    </ul>
                </li>

                <li class="nav-item"><a class="nav-link" href="reports.php">📊 Reports</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">🔒 Logout</a></li>
            </ul>
        </div>
    </div>
</nav>
<div class="container my-5">
    <div class="card shadow-lg border-0">
        <div class="card-body p-4">
            <h2 class="text-center text-primary fw-bold mb-4">Add Purchase Record</h2>
            <form action="process_form.php" method="POST" enctype="multipart/form-data">
                <div class="row g-4">
                    
                    <!-- Client Information -->
                    <div class="col-md-6">
                        <h4 class="text-center text-secondary fw-semibold mb-3">Client Information</h4>
                        <div class="mb-3">
                            <label for="client_name" class="form-label fw-semibold">Client Name</label>
                            <input type="text" class="form-control" id="client_name" name="client_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="mobile" class="form-label fw-semibold">Mobile No.</label>
                            <input type="text" class="form-control" id="mobile" name="mobile" required>
                        </div>
                        <div class="mb-3">
                            <label for="address" class="form-label fw-semibold">Address</label>
                            <textarea class="form-control" id="address" name="address" rows="2" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="village" class="form-label fw-semibold">Village/Town/City</label>
                            <input type="text" class="form-control" id="village" name="village" required>
                        </div>
                        <div class="mb-3">
                            <label for="purchase_date" class="form-label fw-semibold">Purchase Date</label>
                            <input type="date" class="form-control" id="purchase_date" name="purchase_date" required>
                        </div>
                    </div>

                    <!-- Vehicle Details -->
                    <div class="col-md-6">
                        <h4 class="text-center text-secondary fw-semibold mb-3">Vehicle Details</h4>
                        <div class="mb-3">
                            <label for="vehicle_name" class="form-label fw-semibold">Vehicle Name</label>
                            <input type="text" class="form-control" id="vehicle_name" name="vehicle_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="rc_no" class="form-label fw-semibold">Vehicle RC No.</label>
                            <input type="text" class="form-control text-uppercase" id="rc_no" name="rc_no" required>
                        </div>
                        <div class="mb-3">
                            <label for="vehicle_price" class="form-label fw-semibold">Vehicle Price</label>
                            <input type="number" class="form-control" id="vehicle_price" name="vehicle_price" min="0" step="0.01" required oninput="calculateBalance()">
                        </div>
                        <div class="mb-3">
                            <label for="paid_amount" class="form-label fw-semibold">Paid Amount</label>
                            <input type="number" class="form-control" id="paid_amount" name="paid_amount" min="0" step="0.01" required oninput="calculateBalance()">
                        </div>
                        <div class="mb-3">
                            <label for="balance_amount" class="form-label fw-semibold">Balance Amount</label>
                            <input type="number" class="form-control bg-light" id="balance_amount" name="balance_amount" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="vehicle_photo" class="form-label fw-semibold">Vehicle Photo</label>
                            <input type="file" class="form-control" id="vehicle_photo" name="vehicle_photo" accept="image/*" required>
                        </div>
                    </div>
                </div>

                <div class="text-center mt-4">
                    <button type="submit" class="btn btn-success px-5 py-2 fw-semibold shadow-sm">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
        function calculateBalance() {
            let price = parseFloat(document.getElementById('vehicle_price').value) || 0;
            let paid = parseFloat(document.getElementById('paid_amount').value) || 0;
            let balance = price - paid;
            document.getElementById('balance_amount').value = balance.toFixed(2);
        }
    </script>
<!-- 📌 Footer -->
<div class="footer mt-5">
    &copy; <?= date("Y"); ?> Shri Shyam Motors | All Rights Reserved
</div>

</body>

</html>
