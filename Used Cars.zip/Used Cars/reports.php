<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

require 'db.php'; // Ensure this connects to your DB

// Fetch Clients Report
$clients_query = "SELECT id, client_name, mobile, rc_no, purchase_date, paid_amount, balance_amount FROM clients ORDER BY purchase_date DESC";
$clients_result = $conn->query($clients_query);
if (!$clients_result) {
    die("Query Error (Clients): " . $conn->error);
}

// Fetch Sales Report
$sales_query = "SELECT sale_id, client_name, mobile, vehicle_name, rc_no, sale_date, paid_amount, balance_amount FROM sales ORDER BY sale_date DESC";
$sales_result = $conn->query($sales_query);
if (!$sales_result) {
    die("Query Error (Sales): " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

	<style>
	.footer {
            background-color: #343a40;
            color: white;
            text-align: center;
            padding: 10px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
<!-- 🚗 Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Shri Shyam Motors</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">🏠 Dashboard</a></li>

                <!-- Purchase Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="purchaseDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        📋 Purchase
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="purchaseDropdown">
                        <li><a class="dropdown-item" href="client_form.php">➕ Add Purchase</a></li>
                        <li><a class="dropdown-item" href="view_clients.php">📜 Purchase History</a></li>
                    </ul>
                </li>

                <!-- Sales Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="salesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        🚗 Sales
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="salesDropdown">
                        <li><a class="dropdown-item" href="sales_form.php">➕ Add Sale</a></li>
                        <li><a class="dropdown-item" href="view_sales.php">📜 Sales History</a></li>
                    </ul>
                </li>

                <li class="nav-item"><a class="nav-link" href="reports.php">📊 Reports</a></li>
                <li class="nav-item"><a class="nav-link" href="logout.php">🔒 Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h2 class="text-center mb-4">📋 Reports</h2>

    <div class="row">
        <!-- Clients Report (Left Side) -->
        <div class="col-md-6">
            <h3 class="text-primary text-center">👤 Purchase Report</h3>
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>Client ID</th>
                            <th>Name</th>
                            <th>Mobile</th>
                            <th>Reg. No.</th>
                            <th>Purchase Date</th>
                            <th>Paid</th>
                            <th>Balance</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $clients_result->fetch_assoc()) { ?>
                        <tr>
                            <td><?= htmlspecialchars($row["id"]) ?></td>
                            <td><?= htmlspecialchars($row["client_name"]) ?></td>
                            <td><?= htmlspecialchars($row["mobile"]) ?></td>
                            <td><?= strtoupper(htmlspecialchars($row["rc_no"])) ?></td>
                            <td><?= htmlspecialchars($row["purchase_date"]) ?></td>
                            <td>₹<?= number_format($row["paid_amount"], 2) ?></td>
                            <td>₹<?= number_format($row["balance_amount"], 2) ?></td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Sales Report (Right Side) -->
        <div class="col-md-6">
            <h3 class="text-success text-center">🚗 Sales Report</h3>
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>Sale ID</th>
                            <th>Name</th>
                            <th>Mobile</th>
                            
                            <th>Reg. No.</th>
                            <th>Sale Date</th>
                            <th>Paid</th>
                            <th>Balance</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $sales_result->fetch_assoc()) { ?>
                        <tr>
                            <td><?= htmlspecialchars($row["sale_id"]) ?></td>
                            <td><?= htmlspecialchars($row["client_name"]) ?></td>
                            <td><?= htmlspecialchars($row["mobile"]) ?></td>
                            <td><?= strtoupper(htmlspecialchars($row["rc_no"])) ?></td>
                            <td><?= htmlspecialchars($row["sale_date"]) ?></td>
                            <td>₹<?= number_format($row["paid_amount"], 2) ?></td>
                            <td>₹<?= number_format($row["balance_amount"], 2) ?></td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- 📌 Footer -->
    <div class="footer">
        &copy; <?= date("Y"); ?> Shri Shyam Motors | All Rights Reserved
    </div>

</body>
</html>
