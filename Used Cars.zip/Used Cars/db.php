<?php
$servername = "localhost"; // Change if different
$username = "root"; // Default for XAMPP
$password = ""; // Default for XAMPP
$dbname = "car_dealership"; // Ensure correct database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
