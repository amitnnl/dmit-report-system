<?php
function sanitizeInput($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

function validatePassword($password) {
    return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $password);
}

function sendResetEmail($email, $token) {
    $resetLink = "http://".$_SERVER['HTTP_HOST']."/fingerprint/frontend/auth/reset-password.php?token=".$token;
    return $resetLink; // In production, send actual email
}
?>