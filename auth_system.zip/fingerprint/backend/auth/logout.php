<?php
// Correct path resolution for fingerprint installation
define('ROOT_PATH', dirname(__DIR__, 2)); // Points to fingerprint/ directory

// Load required files with absolute paths
require_once ROOT_PATH . '/backend/config/database.php';
require_once ROOT_PATH . '/backend/classes/User.php';
require_once ROOT_PATH . '/backend/classes/Auth.php';

// Initialize session securely
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/fingerprint/',
        'domain' => $_SERVER['HTTP_HOST'],
        'secure' => false, // Set to true in production with HTTPS
        'httponly' => true,
        'samesite' => 'Strict'
    ]);
    session_start();
}

// Initialize database connection
try {
    $database = new Database();
    $db = $database->getConnection();
    
    // Clear remember token if exists
    if (isset($_COOKIE['remember_token'])) {
        // Clear from database if user is logged in
        if (isset($_SESSION['user_id'])) {
            $user = new User($db);
            $user->id = $_SESSION['user_id'];
            
            $query = "UPDATE users SET remember_token = NULL, remember_expiry = NULL WHERE id = ?";
            $stmt = $db->prepare($query);
            $stmt->execute([$user->id]);
        }
        
        // Clear cookie
        setcookie('remember_token', '', [
            'expires' => time() - 3600,
            'path' => '/fingerprint/',
            'domain' => $_SERVER['HTTP_HOST'],
            'secure' => false,
            'httponly' => true,
            'samesite' => 'Strict'
        ]);
    }

    // Destroy all session data
    $_SESSION = [];

    // Remove session cookie
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(), 
            '', 
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"], 
            $params["httponly"]
        );
    }

    // Destroy session
    session_destroy();

    // Redirect to login page
    header("Location: /fingerprint/frontend/auth/login.php");
    exit();

} catch (Exception $e) {
    // Log error and redirect even if logout fails
    error_log("Logout error: " . $e->getMessage());
    header("Location: /fingerprint/frontend/auth/login.php");
    exit();
}
?>