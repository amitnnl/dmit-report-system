<?php
class User {
    private $conn;
    private $table_name = "users";

    public $id;
    public $username;
    public $email;
    public $password;
    public $role;
    public $created_at;
    public $reset_token;
    public $token_expiry;

    public function __construct($db) {
        $this->conn = $db;
    }
	
	public function getByRememberToken($token) {
    $query = "SELECT id, username, email, role FROM " . $this->table_name . " 
              WHERE remember_token = ? AND remember_expiry > NOW() LIMIT 1";
              
    $stmt = $this->conn->prepare($query);
    $stmt->execute([$token]);
    
    if ($stmt->rowCount() > 0) {
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    return false;
}

    public function create() {
        $query = "INSERT INTO " . $this->table_name . " 
                  SET username=:username, email=:email, password=:password, role=:role, created_at=:created_at";
        
        $stmt = $this->conn->prepare($query);
        
        $this->username = htmlspecialchars(strip_tags($this->username));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->password = password_hash($this->password, PASSWORD_BCRYPT);
        $this->role = htmlspecialchars(strip_tags($this->role));
        $this->created_at = date('Y-m-d H:i:s');
        
        $stmt->bindParam(":username", $this->username);
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":password", $this->password);
        $stmt->bindParam(":role", $this->role);
        $stmt->bindParam(":created_at", $this->created_at);
        
        return $stmt->execute();
    }

    public function emailExists() {
        $query = "SELECT id, username, password, role FROM " . $this->table_name . " WHERE email = ? LIMIT 0,1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->email);
        $stmt->execute();
        $num = $stmt->rowCount();
        
        if($num > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $this->id = $row['id'];
            $this->username = $row['username'];
            $this->password = $row['password'];
            $this->role = $row['role'];
            return true;
        }
        return false;
    }

    public function updateResetToken() {
        $query = "UPDATE " . $this->table_name . " 
                  SET reset_token = :token, token_expiry = :expiry 
                  WHERE email = :email";
        
        $stmt = $this->conn->prepare($query);
        
        $this->reset_token = bin2hex(random_bytes(32));
        $this->token_expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        $stmt->bindParam(":token", $this->reset_token);
        $stmt->bindParam(":expiry", $this->token_expiry);
        $stmt->bindParam(":email", $this->email);
        
        return $stmt->execute();
    }

    public function isValidToken() {
        $query = "SELECT id FROM " . $this->table_name . " 
                  WHERE reset_token = :token AND token_expiry > NOW()";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":token", $this->reset_token);
        $stmt->execute();
        
        return $stmt->rowCount() > 0;
    }

    public function updatePassword() {
        $query = "UPDATE " . $this->table_name . " 
                  SET password = :password, reset_token = NULL, token_expiry = NULL 
                  WHERE reset_token = :token";
        
        $stmt = $this->conn->prepare($query);
        
        $this->password = password_hash($this->password, PASSWORD_BCRYPT);
        
        $stmt->bindParam(":password", $this->password);
        $stmt->bindParam(":token", $this->reset_token);
        
        return $stmt->execute();
    }
}
?>