<?php
class Auth {
    public static function authenticate($user) {
        $_SESSION['user_id'] = $user->id;
        $_SESSION['username'] = $user->username;
        $_SESSION['email'] = $user->email;
        $_SESSION['role'] = $user->role;
        $_SESSION['logged_in'] = true;
    }

    public static function checkRememberMe() {
        if (!empty($_COOKIE['remember_token']) && !self::isLoggedIn()) {
            $database = new Database();
            $db = $database->getConnection();
            $user = new User($db);
            
            $userData = $user->getByRememberToken($_COOKIE['remember_token']);
            
            if ($userData) {
                $user->id = $userData['id'];
                $user->username = $userData['username'];
                $user->email = $userData['email'];
                $user->role = $userData['role'];
                
                self::authenticate($user);
                header("Location: /fingerprint/frontend/dashboard/" . $_SESSION['role'] . "/index.php");
                exit();
            }
        }
    }

    public static function isLoggedIn() {
        return isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
    }

    public static function isAdmin() {
        return self::isLoggedIn() && $_SESSION['role'] === 'admin';
    }

    public static function isUser() {
        return self::isLoggedIn() && $_SESSION['role'] === 'user';
    }

    public static function logout() {
        // Clear remember token if exists
        if (isset($_COOKIE['remember_token'])) {
            setcookie('remember_token', '', time() - 3600, '/fingerprint/');
            
            // Clear from database
            $database = new Database();
            $db = $database->getConnection();
            $user = new User($db);
            $user->id = $_SESSION['user_id'];
            
            $query = "UPDATE users SET remember_token = NULL, remember_expiry = NULL WHERE id = ?";
            $stmt = $db->prepare($query);
            $stmt->execute([$user->id]);
        }
        
        session_unset();
        session_destroy();
    }

    public static function redirectIfNotLoggedIn() {
        if (!self::isLoggedIn()) {
            header("Location: /fingerprint/frontend/auth/login.php");
            exit();
        }
    }

    public static function redirectIfNotAdmin() {
        self::redirectIfNotLoggedIn();
        if (!self::isAdmin()) {
            header("Location: /fingerprint/frontend/dashboard/user/index.php");
            exit();
        }
    }

    public static function redirectIfLoggedIn() {
        self::checkRememberMe();
        
        if (self::isLoggedIn()) {
            header("Location: /fingerprint/frontend/dashboard/" . $_SESSION['role'] . "/index.php");
            exit();
        }
    }
}
?>