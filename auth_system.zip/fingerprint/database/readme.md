fingerprint/
├── backend/
│   ├── auth/
│   │   ├── login.php
│   │   ├── register.php
│   │   ├── logout.php
│   │   ├── forgot-password.php
│   │   └── reset-password.php
│   ├── config/
│   │   └── database.php
│   ├── classes/
│   │   ├── User.php
│   │   └── Auth.php
│   └── functions/
│       └── helpers.php
├── frontend/
│   ├── assets/
│   │   ├── css/
│   │   ├── js/
│   │   └── images/
│   ├── includes/
│   │   ├── header.php
│   │   └── footer.php
│   ├── auth/
│   │   ├── login.php
│   │   ├── register.php
│   │   ├── forgot-password.php
│   │   └── reset-password.php
│   ├── dashboard/
│   │   ├── index.php
│   │   ├── admin/
│   │   │   └── index.php
│   │   └── user/
│   │       └── index.php
│   └── search.php
└── index.php



This complete implementation provides all the files you need for your 
authentication system with the exact structure you specified. 

The system includes:

User and admin registration

Login/logout functionality

Password recovery system

Separate dashboards for users and admins

Search functionality

Responsive design using Bootstrap

Proper separation of frontend and backend code

To implement this system:

Create the database using the provided schema

Update the database credentials in backend/config/database.php

Upload all files to your web server

Access the system through your browser

The default admin credentials are:

	For Admin Panel

		Email: admin@test.com

		Password: Admin@123
		
	For User Panel
	
		Email: user@test.com

		Password: User@123