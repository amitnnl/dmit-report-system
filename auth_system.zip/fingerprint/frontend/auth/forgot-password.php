<?php
require_once '../../backend/config/database.php';
require_once '../../backend/classes/User.php';
require_once '../../backend/functions/helpers.php';

session_start();

$database = new Database();
$db = $database->getConnection();

$user = new User($db);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user->email = $_POST['email'];

    if (empty($user->email)) {
        $error = 'Please enter your email';
    } elseif (!filter_var($user->email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email format';
    } else {
        if ($user->emailExists()) {
            if ($user->updateResetToken()) {
                $resetLink = sendResetEmail($user->email, $user->reset_token);
                $success = 'Password reset link has been generated. In a real application, this would be emailed to you.<br>For testing: <a href="'.$resetLink.'">'.$resetLink.'</a>';
            } else {
                $error = 'Failed to generate reset token. Please try again.';
            }
        } else {
            $error = 'Email not found';
        }
    }
}

$pageTitle = "Forgot Password";
require_once '../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h4>Forgot Password</h4>
            </div>
            <div class="card-body">
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <form method="post" action="">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Send Reset Link</button>
                </form>
                <div class="mt-3">
                    Remember your password? <a href="login.php">Login here</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>