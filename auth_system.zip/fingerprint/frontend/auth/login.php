<?php
define('ROOT_PATH', dirname(__DIR__, 2)); // Points to fingerprint/
require_once ROOT_PATH . '/backend/config/database.php';
require_once ROOT_PATH . '/backend/classes/User.php';
require_once ROOT_PATH . '/backend/classes/Auth.php';

session_start();

// Redirect if already logged in
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']) {
    header("Location: /fingerprint/frontend/dashboard/" . $_SESSION['role'] . "/index.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();
$user = new User($db);

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember']);

    try {
        if (empty($email) || empty($password)) {
            throw new Exception('Please fill all fields');
        }

        $user->email = $email;
        
        if (!$user->emailExists()) {
            throw new Exception('Email not found');
        }

        if (!password_verify($password, $user->password)) {
            throw new Exception('Invalid password');
        }

        // Authentication successful
        Auth::authenticate($user);

        // Remember me functionality
        if ($remember) {
            $token = bin2hex(random_bytes(32));
            $expiry = time() + (30 * 24 * 60 * 60); // 30 days
            
            setcookie('remember_token', $token, $expiry, '/fingerprint/');
            // Store token in database (implementation needed)
        }

        // Redirect to dashboard
        header("Location: /fingerprint/frontend/dashboard/" . $user->role . "/index.php");
        exit();

    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

$pageTitle = "Login";
require_once ROOT_PATH . '/frontend/includes/header.php';
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-4">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><i class="bi bi-box-arrow-in-right me-2"></i>Login</h4>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <?php echo htmlspecialchars($error); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <form method="post" novalidate>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control <?php echo $error && !empty($email) ? 'is-invalid' : ''; ?>" 
                                   id="email" name="email" required
                                   value="<?php echo htmlspecialchars($email); ?>">
                            <?php if ($error && !empty($email)): ?>
                                <div class="invalid-feedback">Please check your email</div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control <?php echo $error ? 'is-invalid' : ''; ?>" 
                                   id="password" name="password" required>
                            <?php if ($error): ?>
                                <div class="invalid-feedback">Please check your password</div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="remember" name="remember">
                            <label class="form-check-label" for="remember">Remember me</label>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100 mb-3">
                            <i class="bi bi-box-arrow-in-right me-2"></i>Login
                        </button>
                        
                        <div class="text-center">
                            <a href="/fingerprint/frontend/auth/forgot-password.php" class="text-decoration-none">
                                Forgot password?
                            </a>
                        </div>
                    </form>
                </div>
                <div class="card-footer text-center">
                    Don't have an account? 
                    <a href="/fingerprint/frontend/auth/register.php" class="text-decoration-none">
                        Register here
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
require_once ROOT_PATH . '/frontend/includes/footer.php'; 
?>