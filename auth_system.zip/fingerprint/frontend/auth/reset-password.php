<?php
require_once '../../backend/config/database.php';
require_once '../../backend/classes/User.php';
require_once '../../backend/functions/helpers.php';

session_start();

$database = new Database();
$db = $database->getConnection();

$user = new User($db);

$error = '';
$success = '';

$token = $_GET['token'] ?? '';
$user->reset_token = $token;

if (empty($token) || !$user->isValidToken()) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($password) || empty($confirm_password)) {
        $error = 'Please fill all fields';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match';
    } elseif (!validatePassword($password)) {
        $error = 'Password must be at least 8 characters with uppercase, lowercase, number, and special character';
    } else {
        $user->password = $password;
        if ($user->updatePassword()) {
            $success = 'Password updated successfully. You can now login.';
        } else {
            $error = 'Failed to update password. Please try again.';
        }
    }
}

$pageTitle = "Reset Password";
require_once '../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h4>Reset Password</h4>
            </div>
            <div class="card-body">
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <form method="post" action="">
                    <div class="mb-3">
                        <label for="password" class="form-label">New Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                        <small class="text-muted">Minimum 8 characters with uppercase, lowercase, number, and special character</small>
                    </div>
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Reset Password</button>
                </form>
                <div class="mt-3">
                    <a href="login.php">Back to login</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>