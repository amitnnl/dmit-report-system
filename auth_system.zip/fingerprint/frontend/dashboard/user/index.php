<?php
require_once __DIR__ . '/../../../backend/config/database.php';
require_once __DIR__ . '/../../../backend/classes/User.php';
require_once __DIR__ . '/../../../backend/classes/Auth.php';
require_once __DIR__ . '/../../../backend/functions/helpers.php';

session_start();
Auth::redirectIfNotLoggedIn();

$pageTitle = "User Dashboard";
require_once '../../includes/header.php';
?>

<div class="container">
    <h1 class="mt-4">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></h1>
    <div class="row mt-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Profile</h5>
                    <p class="card-text">Update your profile information</p>
                    <a href="#" class="btn btn-primary">Edit Profile</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Settings</h5>
                    <p class="card-text">Change your password and preferences</p>
                    <a href="#" class="btn btn-primary">Settings</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>