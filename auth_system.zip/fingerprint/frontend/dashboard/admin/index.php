<?php
require_once __DIR__ . '/../../../backend/config/database.php';
require_once __DIR__ . '/../../../backend/classes/User.php';
require_once __DIR__ . '/../../../backend/classes/Auth.php';
require_once __DIR__ . '/../../../backend/functions/helpers.php';

session_start();
Auth::redirectIfNotAdmin();

$pageTitle = "Admin Dashboard";
require_once '../../includes/header.php';
?>

<div class="container">
    <h1 class="mt-4">Admin Dashboard</h1>
    <div class="row mt-4">
        <div class="col-md-4">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h5 class="card-title">Users</h5>
                    <p class="card-text">Manage all users</p>
                    <a href="#" class="btn btn-light">View</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h5 class="card-title">Settings</h5>
                    <p class="card-text">System configuration</p>
                    <a href="#" class="btn btn-light">View</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <h5 class="card-title">Reports</h5>
                    <p class="card-text">Generate reports</p>
                    <a href="#" class="btn btn-light">View</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>