<?php
// Set base URL
$base_url = '/fingerprint';

// Security headers
header("X-Frame-Options: DENY");
header("X-Content-Type-Options: nosniff");
header("X-XSS-Protection: 1; mode=block");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Authentication System">
    
    <title><?php echo htmlspecialchars($pageTitle ?? 'Auth System'); ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo $base_url; ?>/frontend/assets/css/style.css">
    
    <!-- Favicon -->
    <link rel="icon" href="<?php echo $base_url; ?>/frontend/assets/images/favicon.ico">
</head>
<body>
    <!-- Navigation will be included here -->
    <?php require_once __DIR__ . '/navigation.php'; ?>
    
    <main class="flex-shrink-0">
