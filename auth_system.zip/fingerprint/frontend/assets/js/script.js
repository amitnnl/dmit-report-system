// Power BI Integration Variables
const powerBiConfig = {
  // Dashboard Embed Settings
  embedUrl: 'https://app.powerbi.com/reportEmbed',
  reportId: '', // Will be set dynamically
  groupId: '', // Will be set dynamically
  accessToken: '', // Will be set via API
  
  // Theme Settings
  theme: {
    primary: getComputedStyle(document.documentElement).getPropertyValue('--powerbi-primary').trim(),
    secondary: getComputedStyle(document.documentElement).getPropertyValue('--powerbi-secondary').trim(),
    background: getComputedStyle(document.documentElement).getPropertyValue('--powerbi-light').trim()
  },
  
  // Layout Settings
  layout: {
    displayOption: 'actualSize',
    pageView: 'fitToWidth'
  }
};

// Fingerprint Analytics Dashboard Loader
function loadPowerBiDashboard(reportConfig) {
  // Merge config with defaults
  const config = {...powerBiConfig, ...reportConfig};
  
  // Create container if not exists
  let container = document.querySelector('.powerbi-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'powerbi-container';
    document.querySelector('main').appendChild(container);
  }
  
  // Create iframe
  const iframe = document.createElement('iframe');
  iframe.className = 'powerbi-iframe';
  
  // Construct embed URL
  const embedUrl = `${config.embedUrl}?reportId=${config.reportId}&groupId=${config.groupId}`;
  iframe.src = embedUrl;
  
  // Append to container
  container.innerHTML = '';
  container.appendChild(iframe);
  
  // Post message to set config
  window.addEventListener('message', function(event) {
    if (event.data === 'powerbi:loaded') {
      iframe.contentWindow.postMessage({
        action: 'setConfig',
        config: {
          theme: config.theme,
          layout: config.layout,
          accessToken: config.accessToken
        }
      }, '*');
    }
  });
}

// Authentication UI Enhancements
document.addEventListener('DOMContentLoaded', function() {
  // Add fingerprint scan animation to auth forms
  const authForms = document.querySelectorAll('[class*="auth-form"]');
  authForms.forEach(form => {
    form.addEventListener('submit', function(e) {
      const submitBtn = this.querySelector('[type="submit"]');
      if (submitBtn) {
        submitBtn.style.position = 'relative';
        submitBtn.style.overflow = 'hidden';
        
        // Add scanning animation
        const scanEffect = document.createElement('span');
        scanEffect.style.position = 'absolute';
        scanEffect.style.top = '0';
        scanEffect.style.left = '0';
        scanEffect.style.width = '100%';
        scanEffect.style.height = '100%';
        scanEffect.style.background = 'rgba(76, 175, 80, 0.3)';
        scanEffect.style.animation = 'fingerprint-scan 1.5s infinite';
        submitBtn.appendChild(scanEffect);
      }
    });
  });
  
  // Error state enhancements
  const errorAlerts = document.querySelectorAll('[class*="alert-danger"]');
  errorAlerts.forEach(alert => {
    alert.style.position = 'relative';
    alert.style.paddingLeft = '50px';
    
    const icon = document.createElement('i');
    icon.className = 'bi bi-fingerprint';
    icon.style.position = 'absolute';
    icon.style.left = '15px';
    icon.style.top = '50%';
    icon.style.transform = 'translateY(-50%)';
    icon.style.fontSize = '1.5rem';
    alert.prepend(icon);
  });
});