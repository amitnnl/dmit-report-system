<?php
require_once 'backend/classes/Auth.php';

session_start();

$pageTitle = "Search";
require_once 'includes/header.php';
?>

<div class="container">
    <h1 class="mt-4">Search</h1>
    <div class="row mt-4">
        <div class="col-md-8 mx-auto">
            <div class="card">
                <div class="card-body">
                    <form action="" method="get">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="Search..." name="query">
                            <button class="btn btn-primary" type="submit">Search</button>
                        </div>
                    </form>
                    
                    <?php if (isset($_GET['query'])): ?>
                        <div class="search-results mt-4">
                            <h5>Search Results for "<?php echo htmlspecialchars($_GET['query']); ?>"</h5>
                            <div class="list-group">
                                <!-- Sample results -->
                                <a href="#" class="list-group-item list-group-item-action">Result 1</a>
                                <a href="#" class="list-group-item list-group-item-action">Result 2</a>
                                <a href="#" class="list-group-item list-group-item-action">Result 3</a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>