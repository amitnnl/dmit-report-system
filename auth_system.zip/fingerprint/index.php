<?php
// Set absolute path to root directory
define('ROOT_PATH', __DIR__);

// Initialize session with secure settings
session_start();

// Load required files
require_once ROOT_PATH . '/backend/classes/Auth.php';

// Set page title
$pageTitle = "Home";

// Include header
require_once ROOT_PATH . '/frontend/includes/header.php';
?>

<div class="container text-center mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow">
                <div class="card-body">
                    <h1 class="display-4 mb-4">Welcome to Our Authentication System</h1>
                    <p class="lead mb-4">Secure access to your digital identity</p>
                    
                    <div class="d-grid gap-3 d-md-block">
                        <a href="/fingerprint/frontend/auth/login.php" class="btn btn-primary btn-lg px-4 me-md-2">
                            <i class="bi bi-box-arrow-in-right me-2"></i>Login
                        </a>
                        <a href="/fingerprint/frontend/auth/register.php" class="btn btn-success btn-lg px-4">
                            <i class="bi bi-person-plus me-2"></i>Register
                        </a>
                    </div>
                    
                    <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']): ?>
                        <div class="mt-4">
                            <p>You are already logged in as <?php echo htmlspecialchars($_SESSION['username']); ?></p>
                            <a href="/fingerprint/frontend/dashboard/<?php echo $_SESSION['role']; ?>/index.php" class="btn btn-outline-dark">
                                Go to Dashboard
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
// Include footer
require_once ROOT_PATH . '/frontend/includes/footer.php'; 
?>