<?php
require_once __DIR__ . '../../config/db.php';
require_once __DIR__ . '../../includes/auth.php';

redirectIfNotAdmin();

include __DIR__ . '../../includes/header.php';
?>

<div class="row">
    <div class="col-md-4 mb-4">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <h5 class="card-title">Total Clients</h5>
                <?php
                $stmt = $pdo->query("SELECT COUNT(*) FROM clients");
                $totalClients = $stmt->fetchColumn();
                ?>
                <h2 class="card-text"><?php echo $totalClients; ?></h2>
            </div>
        </div>
    </div>
    
    <div class="col-md-4 mb-4">
        <div class="card bg-success text-white">
            <div class="card-body">
                <h5 class="card-title">Total Users</h5>
                <?php
                $stmt = $pdo->query("SELECT COUNT(*) FROM users");
                $totalUsers = $stmt->fetchColumn();
                ?>
                <h2 class="card-text"><?php echo $totalUsers; ?></h2>
            </div>
        </div>
    </div>
    
    <div class="col-md-4 mb-4">
        <div class="card bg-info text-white">
            <div class="card-body">
                <h5 class="card-title">Recent Activity</h5>
                <p class="card-text">Last 5 clients added</p>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h4>Recent Clients</h4>
    </div>
    <div class="card-body">
        <?php
        // Updated query to match your actual database schema
        $stmt = $pdo->query("SELECT c.*, u.name as user_name 
                            FROM clients c 
                            JOIN users u ON c.user_id = u.id 
                            ORDER BY c.created_at DESC 
                            LIMIT 5");
        $recentClients = $stmt->fetchAll();
        ?>
        
        <?php if (empty($recentClients)): ?>
        <div class="alert alert-info">No clients found.</div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>Added By</th>
                        <th>Date Added</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentClients as $client): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($client['client_name']); ?></td>
                        <td><?php echo htmlspecialchars($client['email']); ?></td>
                        <td><?php echo htmlspecialchars($client['mobile_no']); ?></td>
                        <td><?php echo htmlspecialchars($client['user_name']); ?></td>
                        <td><?php echo date('M j, Y', strtotime($client['created_at'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '../../includes/footer.php'; ?>