<?php
require_once __DIR__ . '../../config/db.php';
require_once __DIR__ . '../../includes/auth.php';

redirectIfNotAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_POST['user_id'] ?? 0;
    $newRole = $_POST['new_role'] ?? 'user';
    
    // Validate role
    if (!in_array($newRole, ['admin', 'user'])) {
        header("Location: " . APP_URL . "/admin/users.php");
        exit();
    }
    
    // Don't allow changing your own role
    if ($userId == $_SESSION['user_id']) {
        header("Location: " . APP_URL . "/admin/users.php");
        exit();
    }
    
    // Update role
    $stmt = $pdo->prepare("UPDATE users SET role = ? WHERE id = ?");
    $stmt->execute([$newRole, $userId]);
}

header("Location: " . APP_URL . "/admin/users.php");
exit();
?>