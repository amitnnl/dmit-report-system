<?php
require_once __DIR__ . '../../config/db.php';
require_once __DIR__ . '../../includes/auth.php';

redirectIfNotLoggedIn();

// Set upload directory (create it if it doesn't exist)
$upload_dir = __DIR__ . '../../uploads/clients/';
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

$error = '';
$success = '';
$purchase_data = null;

// Fetch all purchases for dropdown
$purchases = [];
try {
    $stmt = $pdo->prepare("SELECT id, reg_no, model FROM clients WHERE transaction_type = 'Purchase'");
    $stmt->execute();
    $purchases = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "Error fetching purchases: " . $e->getMessage();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect form data
    $date = $_POST['date'] ?? date('Y-m-d');
    $client_name = $_POST['client_name'] ?? '';
    $mobile_no = $_POST['mobile_no'] ?? '';
    $email = $_POST['email'] ?? '';
    $address = $_POST['address'] ?? '';
    $price = (float)($_POST['price'] ?? 0);
    $payed = (float)($_POST['payed'] ?? 0);
    $transaction_type = $_POST['transaction_type'] ?? '';
    $reg_no = $_POST['reg_no'] ?? '';
    $model = $_POST['model'] ?? '';
    $remarks = $_POST['remarks'] ?? '';
    $document_path = null;
    $purchase_id = ($_POST['purchase_id'] ?? null) ? (int)$_POST['purchase_id'] : null;

    // Clear purchase_id if not a sale
    if ($transaction_type !== 'Sale') {
        $purchase_id = null;
    }

    // If this is a sale and purchase_id is selected, get data from purchase
    if ($transaction_type === 'Sale' && $purchase_id) {
        try {
            // Verify the purchase exists
            $stmt = $pdo->prepare("SELECT id, reg_no, model, document_path FROM clients WHERE id = ? AND transaction_type = 'Purchase'");
            $stmt->execute([$purchase_id]);
            $purchase_data = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($purchase_data) {
                $reg_no = $purchase_data['reg_no'] ?? $reg_no;
                $model = $purchase_data['model'] ?? $model;
                $document_path = $purchase_data['document_path'] ?? $document_path;
            } else {
                $error = "The selected purchase does not exist or is invalid";
            }
        } catch (PDOException $e) {
            $error = "Error fetching purchase data: " . $e->getMessage();
        }
    }

    // Calculate balance
    $balance = $price - $payed;

    // Validate required fields
    if (empty($client_name) || empty($mobile_no) || empty($transaction_type)) {
        $error = "Client name, mobile number, and transaction type are required";
    } elseif (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format";
    } elseif ($transaction_type === 'Sale' && empty($reg_no)) {
        $error = "Registration number is required for sales";
    } else {
        // Process file upload if provided and no document from purchase
        if (empty($document_path) && !empty($_FILES['document']['name'])) {
            $file_name = $_FILES['document']['name'];
            $file_tmp = $_FILES['document']['tmp_name'];
            $file_size = $_FILES['document']['size'];
            $file_error = $_FILES['document']['error'];
            
            // Get file extension
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            
            // Allowed file types
            $allowed = ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx'];
            
            if (in_array($file_ext, $allowed)) {
                if ($file_error === 0) {
                    if ($file_size <= 5242880) { // 5MB max
                        // Generate unique filename
                        $new_file_name = uniqid('', true) . '.' . $file_ext;
                        $file_destination = $upload_dir . $new_file_name;
                        
                        if (move_uploaded_file($file_tmp, $file_destination)) {
                            $document_path = 'uploads/clients/' . $new_file_name;
                        } else {
                            $error = "Error uploading file";
                        }
                    } else {
                        $error = "File size too large (max 5MB)";
                    }
                } else {
                    $error = "Error uploading file";
                }
            } else {
                $error = "Invalid file type. Allowed: JPG, PNG, PDF, DOC, DOCX";
            }
        }

        if (empty($error)) {
            // Insert into database
            $stmt = $pdo->prepare("INSERT INTO clients (
                date, client_name, mobile_no, email, address, 
                price, payed, balance, transaction_type, 
                reg_no, model, remarks, document_path, user_id, linked_purchase_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            try {
                $stmt->execute([
                    $date, $client_name, $mobile_no, $email, $address,
                    $price, $payed, $balance, $transaction_type,
                    $reg_no, $model, $remarks, $document_path, 
                    $_SESSION['user_id'],
                    $transaction_type === 'Sale' ? $purchase_id : null
                ]);
                
                $success = "Client added successfully!";
                header("Refresh: 2; url=" . APP_URL . "/clients/view.php");
                exit;
            } catch (PDOException $e) {
                $error = "Database error: " . $e->getMessage();
                // If foreign key constraint fails, provide more specific error
                if (strpos($e->getMessage(), 'foreign key constraint') !== false) {
                    $error .= ". The selected purchase may not exist.";
                }
            }
        }
    }
}

include __DIR__ . '../../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">Add New Client</h4>
            </div>
            <div class="card-body">
                <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
                <?php endif; ?>
                
                <form method="post" enctype="multipart/form-data" novalidate>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="date" class="form-label">Date *</label>
                                <input type="date" class="form-control" id="date" name="date" 
                                       value="<?php echo htmlspecialchars($date ?? date('Y-m-d')); ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="client_name" class="form-label">Client Name *</label>
                                <input type="text" class="form-control" id="client_name" name="client_name" 
                                       value="<?php echo htmlspecialchars($client_name ?? ''); ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="mobile_no" class="form-label">Mobile Number *</label>
                                <input type="text" class="form-control" id="mobile_no" name="mobile_no" 
                                       value="<?php echo htmlspecialchars($mobile_no ?? ''); ?>" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email"
                                       value="<?php echo htmlspecialchars($email ?? ''); ?>">
                            </div>
                            
                            <div class="mb-3">
                                <label for="address" class="form-label">Address</label>
                                <textarea class="form-control" id="address" name="address" rows="2"><?php echo htmlspecialchars($address ?? ''); ?></textarea>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="transaction_type" class="form-label">Transaction Type *</label>
                                <select class="form-select" id="transaction_type" name="transaction_type" required>
                                    <option value="">Select Type</option>
                                    <option value="Sale" <?php echo (isset($transaction_type) && $transaction_type === 'Sale') ? 'selected' : ''; ?>>Sale</option>
                                    <option value="Purchase" <?php echo (isset($transaction_type) && $transaction_type === 'Purchase') ? 'selected' : ''; ?>>Purchase</option>
                                </select>
                            </div>
                            
                            <div class="mb-3 purchase-selector" style="display: <?php echo (isset($transaction_type) && $transaction_type === 'Sale' ? 'block' : 'none'); ?>;">
                                <label for="purchase_id" class="form-label">Select Purchase</label>
                                <select class="form-select" id="purchase_id" name="purchase_id">
                                    <option value="">-- Select Purchase --</option>
                                    <?php foreach ($purchases as $purchase): ?>
                                    <option value="<?php echo $purchase['id']; ?>" 
                                        <?php echo (isset($purchase_id) && $purchase_id == $purchase['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars(($purchase['reg_no'] ?? 'N/A') . ' - ' . ($purchase['model'] ?? 'N/A')); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                                <small class="text-muted">Select a purchase to auto-fill vehicle details</small>
                            </div>
                            
                            <div class="mb-3">
                                <label for="reg_no" class="form-label">Registration Number <?php echo ($transaction_type ?? '') === 'Sale' ? '*' : ''; ?></label>
                                <input type="text" class="form-control" id="reg_no" name="reg_no" 
                                       value="<?php echo htmlspecialchars($reg_no ?? ''); ?>"
                                       <?php echo ($transaction_type ?? '') === 'Sale' ? 'required' : ''; ?>>
                            </div>
                            
                            <div class="mb-3">
                                <label for="model" class="form-label">Model</label>
                                <input type="text" class="form-control" id="model" name="model" 
                                       value="<?php echo htmlspecialchars($model ?? ''); ?>">
                            </div>
                            
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label for="price" class="form-label">Price *</label>
                                    <input type="number" class="form-control" id="price" name="price" 
                                           step="0.01" min="0" value="<?php echo htmlspecialchars($price ?? 0); ?>" required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="payed" class="form-label">Amount Paid *</label>
                                    <input type="number" class="form-control" id="payed" name="payed" 
                                           step="0.01" min="0" value="<?php echo htmlspecialchars($payed ?? 0); ?>" required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="balance" class="form-label">Balance</label>
                                    <input type="number" class="form-control" id="balance" name="balance" 
                                           step="0.01" value="<?php echo htmlspecialchars($balance ?? 0); ?>" readonly>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="document" class="form-label">Upload Document</label>
                                <input type="file" class="form-control" id="document" name="document"
                                       accept=".jpg,.jpeg,.png,.pdf,.doc,.docx">
                                <small class="text-muted">Max size: 5MB (JPG, PNG, PDF, DOC, DOCX)</small>
                                <?php if (isset($document_path) && !empty($document_path)): ?>
                                <div class="mt-2">
                                    <small>Current document: <?php echo basename($document_path); ?></small>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="mb-3">
                                <label for="remarks" class="form-label">Remarks</label>
                                <textarea class="form-control" id="remarks" name="remarks" rows="2"><?php echo htmlspecialchars($remarks ?? ''); ?></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <a href="<?php echo APP_URL; ?>/clients/view.php" class="btn btn-secondary me-md-2">Cancel</a>
                        <button type="submit" class="btn btn-primary">Add Client</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Auto-calculate balance
document.getElementById('price').addEventListener('input', calculateBalance);
document.getElementById('payed').addEventListener('input', calculateBalance);

function calculateBalance() {
    const price = parseFloat(document.getElementById('price').value) || 0;
    const payed = parseFloat(document.getElementById('payed').value) || 0;
    document.getElementById('balance').value = (price - payed).toFixed(2);
}

// Show/hide purchase selector based on transaction type
document.getElementById('transaction_type').addEventListener('change', function() {
    const purchaseSelector = document.querySelector('.purchase-selector');
    const regNoField = document.getElementById('reg_no');
    
    if (this.value === 'Sale') {
        purchaseSelector.style.display = 'block';
        regNoField.required = true;
    } else {
        purchaseSelector.style.display = 'none';
        document.getElementById('purchase_id').value = '';
        regNoField.required = false;
        
        // Clear auto-filled fields if they came from a purchase
        if (document.getElementById('reg_no').dataset.fromPurchase) {
            document.getElementById('reg_no').value = '';
            document.getElementById('model').value = '';
        }
    }
});

// Auto-fill purchase data when selected
document.getElementById('purchase_id').addEventListener('change', function() {
    if (this.value) {
        fetchPurchaseData(this.value);
    } else {
        // Clear fields if selection is removed
        document.getElementById('reg_no').value = '';
        document.getElementById('model').value = '';
        document.getElementById('reg_no').removeAttribute('data-from-purchase');
    }
});

function fetchPurchaseData(purchaseId) {
    fetch(`<?php echo APP_URL; ?>/clients/purchase.php?id=${purchaseId}`)
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
        .then(data => {
            if (data) {
                if (data.reg_no) {
                    document.getElementById('reg_no').value = data.reg_no;
                    document.getElementById('reg_no').setAttribute('data-from-purchase', 'true');
                }
                if (data.model) {
                    document.getElementById('model').value = data.model;
                }
            }
        })
        .catch(error => {
            console.error('Error fetching purchase data:', error);
            alert('Error loading purchase details. Please try again.');
        });
}

// Initialize form based on current transaction type
document.addEventListener('DOMContentLoaded', function() {
    calculateBalance();
    
    // If coming back with errors and it's a sale, try to fetch purchase data
    const transactionType = document.getElementById('transaction_type').value;
    const purchaseId = document.getElementById('purchase_id').value;
    
    if (transactionType === 'Sale' && purchaseId) {
        fetchPurchaseData(purchaseId);
    }
});

// Preview document name
document.getElementById('document').addEventListener('change', function(e) {
    if (this.files.length > 0) {
        const fileName = this.files[0].name;
        const label = this.nextElementSibling;
        label.textContent = "Selected: " + fileName;
    }
});
</script>

<?php include __DIR__ . '../../includes/footer.php'; ?>