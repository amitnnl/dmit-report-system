<?php
require_once __DIR__ . '../../config/db.php';
require_once __DIR__ . '../../includes/auth.php';

redirectIfNotLoggedIn();

// Get client ID from URL
$clientId = $_GET['id'] ?? 0;
if (!$clientId) {
    header("Location: " . APP_URL . "/clients/view.php");
    exit();
}

try {
    $pdo->beginTransaction();
    
    // First delete related payment history
    $stmt = $pdo->prepare("DELETE FROM payment_history WHERE client_id = ?");
    $stmt->execute([$clientId]);
    
    // Then delete the client
    $stmt = $pdo->prepare("DELETE FROM clients WHERE id = ?");
    $stmt->execute([$clientId]);
    
    $pdo->commit();
    $_SESSION['success'] = "Client deleted successfully";
} catch (PDOException $e) {
    $pdo->rollBack();
    $_SESSION['error'] = "Failed to delete client: " . $e->getMessage();
}

header("Location: " . APP_URL . "/clients/view.php");
exit();
?>