<?php
require_once __DIR__ . '../../config/db.php';
require_once __DIR__ . '../../includes/auth.php';

redirectIfNotLoggedIn();

// Set upload directory
$upload_dir = __DIR__ . '../../uploads/clients/';
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

// Get client ID from URL
$clientId = $_GET['id'] ?? 0;
if (!$clientId) {
    header("Location: " . APP_URL . "/clients/view.php");
    exit();
}

// Handle document removal
if (isset($_GET['remove_document'])) {
    $stmt = $pdo->prepare("SELECT document_path FROM clients WHERE id = ?");
    $stmt->execute([$clientId]);
    $client = $stmt->fetch();
    
    if (!empty($client['document_path']) && file_exists(__DIR__ . '/../../' . $client['document_path'])) {
        unlink(__DIR__ . '/../../' . $client['document_path']);
    }
    
    $stmt = $pdo->prepare("UPDATE clients SET document_path = NULL WHERE id = ?");
    $stmt->execute([$clientId]);
    
    header("Location: " . APP_URL . "/clients/edit.php?id=" . $clientId);
    exit();
}

// Get client data
$stmt = $pdo->prepare("SELECT * FROM clients WHERE id = ?");
$stmt->execute([$clientId]);
$client = $stmt->fetch();

if (!$client) {
    header("Location: " . APP_URL . "/clients/view.php");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date = $_POST['date'] ?? $client['date'];
    $client_name = $_POST['client_name'] ?? '';
    $mobile_no = $_POST['mobile_no'] ?? '';
    $email = $_POST['email'] ?? '';
    $address = $_POST['address'] ?? '';
    $price = (float)($_POST['price'] ?? 0);
    $payed = (float)($_POST['payed'] ?? 0);
    $transaction_type = $_POST['transaction_type'] ?? '';
    $reg_no = $_POST['reg_no'] ?? '';
    $model = $_POST['model'] ?? '';
    $remarks = $_POST['remarks'] ?? '';
    $document_path = $client['document_path'] ?? null;
    
    // Calculate balance
    $balance = $price - $payed;
    
    // Validation
    if (empty($client_name) || empty($mobile_no) || empty($transaction_type)) {
        $error = "Client name, mobile number, and transaction type are required";
    } elseif (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format";
    } else {
        // Handle file upload if new file is provided
        if (isset($_FILES['document']) && $_FILES['document']['error'] === UPLOAD_ERR_OK) {
            // Delete old document if exists
            if (!empty($client['document_path']) && file_exists(__DIR__ . '/../../' . $client['document_path'])) {
                unlink(__DIR__ . '/../../' . $client['document_path']);
            }
            
            // Generate unique filename
            $file_ext = pathinfo($_FILES['document']['name'], PATHINFO_EXTENSION);
            $filename = uniqid() . '.' . $file_ext;
            $target_file = $upload_dir . $filename;
            
            // Validate file
            $allowed_types = ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx'];
            $max_size = 5 * 1024 * 1024; // 5MB
            
            if (!in_array(strtolower($file_ext), $allowed_types)) {
                $error = "Only JPG, PNG, PDF, DOC, DOCX files are allowed";
            } elseif ($_FILES['document']['size'] > $max_size) {
                $error = "File size must be less than 5MB";
            } elseif (move_uploaded_file($_FILES['document']['tmp_name'], $target_file)) {
                $document_path = 'uploads/clients/' . $filename;
            } else {
                $error = "Failed to upload document";
            }
        }
        
        if (empty($error)) {
            // Update client
            $stmt = $pdo->prepare("UPDATE clients SET 
                date = ?,
                client_name = ?,
                mobile_no = ?,
                email = ?,
                address = ?,
                price = ?,
                payed = ?,
                balance = ?,
                transaction_type = ?,
                reg_no = ?,
                model = ?,
                remarks = ?,
                document_path = ?
                WHERE id = ?");
            
            try {
                $stmt->execute([
                    $date,
                    $client_name,
                    $mobile_no,
                    $email,
                    $address,
                    $price,
                    $payed,
                    $balance,
                    $transaction_type,
                    $reg_no,
                    $model,
                    $remarks,
                    $document_path,
                    $clientId
                ]);
                
                // Redirect to view page after successful update
                header("Location: " . APP_URL . "/clients/view.php?success=Client+updated+successfully");
                exit();
            } catch (PDOException $e) {
                $error = "Database error: " . $e->getMessage();
            }
        }
    }
}

include __DIR__ . '../../includes/header.php';
?>

<!-- The rest of your HTML form remains the same -->
<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">Edit Client</h4>
            </div>
            <div class="card-body">
                <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <form method="post" enctype="multipart/form-data">
                    <!-- Your existing form fields here -->
                    <!-- ... -->
                    
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <a href="<?php echo APP_URL; ?>/clients/view.php" class="btn btn-secondary me-md-2">Cancel</a>
                        <button type="submit" class="btn btn-primary">Update Client</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Auto-calculate balance
document.getElementById('price').addEventListener('input', calculateBalance);
document.getElementById('payed').addEventListener('input', calculateBalance);

function calculateBalance() {
    const price = parseFloat(document.getElementById('price').value) || 0;
    const payed = parseFloat(document.getElementById('payed').value) || 0;
    document.getElementById('balance').value = (price - payed).toFixed(2);
}
</script>

<?php include __DIR__ . '../../includes/footer.php'; ?>