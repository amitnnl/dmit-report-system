<?php
require_once __DIR__ . '../../config/db.php';
require_once __DIR__ . '../../includes/auth.php';

redirectIfNotLoggedIn();

header('Content-Type: application/json');

if (!isset($_GET['id'])) {
    echo json_encode(null);
    exit;
}

$purchase_id = (int)$_GET['id'];

try {
    $stmt = $pdo->prepare("SELECT reg_no, model, document_path FROM clients WHERE id = ? AND transaction_type = 'Purchase'");
    $stmt->execute([$purchase_id]);
    $purchase = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode($purchase ?: null);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}