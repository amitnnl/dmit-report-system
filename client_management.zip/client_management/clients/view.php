<?php
require_once __DIR__ . '../../config/db.php';
require_once __DIR__ . '../../includes/auth.php';

redirectIfNotLoggedIn();

// Check if user is admin (you'll need to adjust this based on your user structure)
$isAdmin = $_SESSION['user_role'] === 'admin'; // Adjust this based on your session variable

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;

// Search functionality
$search = isset($_GET['search']) ? $_GET['search'] : '';
$where = '';
$params = [];

if (!empty($search)) {
    $where = "WHERE client_name LIKE :search OR email LIKE :search OR mobile_no LIKE :search";
    $params[':search'] = "%$search%";
}

// Get total clients for pagination
$stmt = $pdo->prepare("SELECT COUNT(*) FROM clients $where");
$stmt->execute($params);
$total = $stmt->fetchColumn();
$totalPages = ceil($total / $perPage);

// Get clients
$stmt = $pdo->prepare("SELECT * FROM clients $where ORDER BY created_at DESC LIMIT $perPage OFFSET $offset");
$stmt->execute($params);
$clients = $stmt->fetchAll();

// Handle delete action if admin
if ($isAdmin && isset($_GET['delete_id'])) {
    $deleteId = (int)$_GET['delete_id'];
    
    try {
        // First check if client exists
        $stmt = $pdo->prepare("SELECT document_path FROM clients WHERE id = ?");
        $stmt->execute([$deleteId]);
        $client = $stmt->fetch();
        
        if ($client) {
            // Delete document if exists
            if (!empty($client['document_path']) && file_exists(__DIR__ . '/../../' . $client['document_path'])) {
                unlink(__DIR__ . '/../../' . $client['document_path']);
            }
            
            // Delete client
            $stmt = $pdo->prepare("DELETE FROM clients WHERE id = ?");
            $stmt->execute([$deleteId]);
            
            $_SESSION['success'] = "Client deleted successfully";
            header("Location: " . APP_URL . "/clients/view.php");
            exit();
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "Error deleting client: " . $e->getMessage();
        header("Location: " . APP_URL . "/clients/view.php");
        exit();
    }
}

include __DIR__ . '../../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Clients</h2>
    <a href="<?php echo APP_URL; ?>/clients/add.php" class="btn btn-primary">Add New Client</a>
</div>

<!-- Display messages -->
<?php if (isset($_SESSION['error'])): ?>
<div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
<?php endif; ?>

<?php if (isset($_SESSION['success'])): ?>
<div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
<?php endif; ?>

<!-- Search Form -->
<form method="get" class="mb-4">
    <div class="input-group">
        <input type="text" name="search" class="form-control" placeholder="Search clients..." value="<?php echo htmlspecialchars($search); ?>">
        <button class="btn btn-outline-secondary" type="submit">Search</button>
        <?php if (!empty($search)): ?>
        <a href="<?php echo APP_URL; ?>/clients/view.php" class="btn btn-outline-danger">Clear</a>
        <?php endif; ?>
    </div>
</form>

<?php if (empty($clients)): ?>
<div class="alert alert-info">No clients found.</div>
<?php else: ?>
<div class="table-responsive">
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>ID</th>
                <th>Date</th>
                <th>Client Name</th>
                <th>Mobile</th>
                <th>Transaction</th>
                <th>Reg. Number</th>
                <th>Balance</th>
                <th>Document</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($clients as $client): ?>
            <tr>
                <td><?php echo $client['id']; ?></td>
                <td><?php echo date('M j, Y', strtotime($client['date'])); ?></td>
                <td><?php echo htmlspecialchars($client['client_name']); ?></td>
                <td><?php echo htmlspecialchars($client['mobile_no']); ?></td>
                <td><?php echo htmlspecialchars($client['transaction_type']); ?></td>
                <td><?php echo htmlspecialchars($client['reg_no']); ?></td>
                <td><?php echo number_format($client['balance'], 2); ?></td>
                <td>
                    <?php if (!empty($client['document_path'])): ?>
                        <a href="<?php echo APP_URL . '/' . $client['document_path']; ?>" 
                           target="_blank" 
                           class="btn btn-sm btn-info"
                           title="<?php echo basename($client['document_path']); ?>">
                            <i class="bi bi-file-earmark"></i> View
                        </a>
                    <?php else: ?>
                        <span class="text-muted">None</span>
                    <?php endif; ?>
                </td>
                <td>
                    <div class="btn-group" role="group">
                        <a href="<?php echo APP_URL; ?>/clients/edit.php?id=<?php echo $client['id']; ?>" 
                           class="btn btn-sm btn-warning">
                            <i class="bi bi-pencil"></i> Edit
                        </a>
                        <?php if ($isAdmin): ?>
                        <a href="<?php echo APP_URL; ?>/clients/view.php?delete_id=<?php echo $client['id']; ?>" 
                           class="btn btn-sm btn-danger" 
                           onclick="return confirm('Are you sure you want to delete this client? This action cannot be undone.')">
                            <i class="bi bi-trash"></i> Delete
                        </a>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Pagination -->
<nav>
    <ul class="pagination justify-content-center">
        <?php if ($page > 1): ?>
        <li class="page-item">
            <a class="page-link" href="?page=<?php echo $page - 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">
                &laquo; Previous
            </a>
        </li>
        <?php endif; ?>
        
        <?php 
        // Show limited pagination links
        $start = max(1, $page - 2);
        $end = min($totalPages, $page + 2);
        
        if ($start > 1) {
            echo '<li class="page-item"><a class="page-link" href="?page=1">1</a></li>';
            if ($start > 2) {
                echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
        }
        
        for ($i = $start; $i <= $end; $i++): ?>
        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
            <a class="page-link" href="?page=<?php echo $i; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">
                <?php echo $i; ?>
            </a>
        </li>
        <?php endfor; 
        
        if ($end < $totalPages) {
            if ($end < $totalPages - 1) {
                echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
            echo '<li class="page-item"><a class="page-link" href="?page='.$totalPages.'">'.$totalPages.'</a></li>';
        }
        ?>
        
        <?php if ($page < $totalPages): ?>
        <li class="page-item">
            <a class="page-link" href="?page=<?php echo $page + 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">
                Next &raquo;
            </a>
        </li>
        <?php endif; ?>
    </ul>
</nav>
<?php endif; ?>

<?php include __DIR__ . '../../includes/footer.php'; ?>