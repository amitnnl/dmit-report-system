<?php
// Initialize session only once
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Load configuration
require_once __DIR__ . '/../config/db.php';

// Load common functions
require_once __DIR__ . '/auth.php';