<?php defined('APP_URL') or define('APP_URL', 'http://localhost/client_management'); ?>
<?php defined('ASSETS_URL') or define('ASSETS_URL', APP_URL . '/assets'); ?>

    </div> <!-- Close main container div -->

    <!-- Footer Content -->
    <footer class="bg-dark text-white mt-5">
        <div class="container py-4">
            <div class="row">
                <div class="col-md-6">
                    <h5>Client Management System</h5>
                    <p>&copy; <?php echo date('Y'); ?> All Rights Reserved</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p>Version 1.0.0</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- JavaScript Libraries -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo ASSETS_URL; ?>/js/script.js"></script>
    
    <?php if (defined('ADDITIONAL_SCRIPTS')): ?>
        <?php echo ADDITIONAL_SCRIPTS; ?>
    <?php endif; ?>
</body>
</html>