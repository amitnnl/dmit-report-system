<?php
// Database configuration
$host = 'localhost';
$dbname = 'client_management';
$username = 'root';
$password = '';

// Path configuration
define('BASE_PATH', realpath(__DIR__ . '/..'));
define('APP_URL', 'http://localhost/client_management');
define('ASSETS_URL', APP_URL . '/assets');

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Could not connect to the database: " . $e->getMessage());
}

// Session start
session_start();
?>