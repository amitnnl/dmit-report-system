<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';

redirectIfNotLoggedIn();

// Handle Excel export
if (isset($_GET['export'])) {
    $exportType = $_GET['export'];
    
    if ($exportType === 'outstanding') {
        // Export outstanding balances
        $stmt = $pdo->prepare("SELECT client_name, mobile_no, price, payed, balance 
                              FROM clients 
                              WHERE balance > 0 
                              ORDER BY balance DESC");
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="outstanding_balances_'.date('Y-m-d').'.xls"');
        header('Cache-Control: max-age=0');
        
        echo "Client Name\tMobile Number\tTotal Amount\tAmount Paid\tOutstanding Balance\n";
        foreach ($data as $row) {
            echo implode("\t", [
                $row['client_name'],
                $row['mobile_no'],
                number_format($row['price'], 2),
                number_format($row['payed'], 2),
                number_format($row['balance'], 2)
            ]) . "\n";
        }
        exit();
    } 
    elseif ($exportType === 'payments') {
        // Export recent payments
        $stmt = $pdo->prepare("SELECT p.payment_date, c.client_name, p.amount, u.name as recorded_by
                             FROM payments p
                             JOIN clients c ON p.client_id = c.id
                             JOIN users u ON p.recorded_by = u.id
                             ORDER BY p.payment_date DESC");
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="recent_payments_'.date('Y-m-d').'.xls"');
        header('Cache-Control: max-age=0');
        
        echo "Payment Date\tClient Name\tAmount\tRecorded By\n";
        foreach ($data as $row) {
            echo implode("\t", [
                date('Y-m-d H:i', strtotime($row['payment_date'])),
                $row['client_name'],
                number_format($row['amount'], 2),
                $row['recorded_by']
            ]) . "\n";
        }
        exit();
    }
}

// Handle payment update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_payment'])) {
    $clientId = $_POST['client_id'];
    $paymentAmount = (float)$_POST['payment_amount'];
    
    try {
        $pdo->beginTransaction();
        
        // Get current payment status
        $stmt = $pdo->prepare("SELECT payed, price FROM clients WHERE id = ?");
        $stmt->execute([$clientId]);
        $client = $stmt->fetch();
        
        // Calculate new values
        $newPayed = $client['payed'] + $paymentAmount;
        $newBalance = $client['price'] - $newPayed;
        
        // Update payment
        $stmt = $pdo->prepare("UPDATE clients SET payed = ?, balance = ? WHERE id = ?");
        $stmt->execute([$newPayed, $newBalance, $clientId]);
        
        // Record payment transaction
        $stmt = $pdo->prepare("INSERT INTO payments (client_id, amount, payment_date, recorded_by) 
                              VALUES (?, ?, NOW(), ?)");
        $stmt->execute([$clientId, $paymentAmount, $_SESSION['user_id']]);
        
        $pdo->commit();
        $_SESSION['success'] = "Payment updated successfully";
        header("Location: " . APP_URL . "/reports.php");
        exit();
    } catch (PDOException $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Payment update failed: " . $e->getMessage();
    }
}

// Get financial statistics
$stmt = $pdo->query("SELECT 
    COUNT(*) as total_clients,
    SUM(price) as total_sales,
    SUM(payed) as total_payments,
    SUM(balance) as total_balance
    FROM clients");
$stats = $stmt->fetch();

// Get clients with outstanding balances
$stmt = $pdo->query("SELECT id, client_name, mobile_no, price, payed, balance 
                     FROM clients 
                     WHERE balance > 0 
                     ORDER BY balance DESC 
                     LIMIT 10");
$outstandingClients = $stmt->fetchAll();

// Get recent payments (including payment ID for deletion)
$stmt = $pdo->query("SELECT p.id, p.amount, p.payment_date, c.client_name, u.name as recorded_by
                     FROM payments p
                     JOIN clients c ON p.client_id = c.id
                     JOIN users u ON p.recorded_by = u.id
                     ORDER BY p.payment_date DESC
                     LIMIT 10");
$recentPayments = $stmt->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<div class="container-fluid">
    <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-3 mb-4">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h5 class="card-title">Total Clients</h5>
                    <h2 class="card-text"><?php echo $stats['total_clients']; ?></h2>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h5 class="card-title">Total Sales</h5>
                    <h2 class="card-text"><?php echo number_format($stats['total_sales'], 2); ?></h2>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <h5 class="card-title">Total Payments</h5>
                    <h2 class="card-text"><?php echo number_format($stats['total_payments'], 2); ?></h2>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <h5 class="card-title">Outstanding Balance</h5>
                    <h2 class="card-text"><?php echo number_format($stats['total_balance'], 2); ?></h2>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Top 10 Outstanding Balances</h4>
                    <div>
                        <a href="?export=outstanding" class="btn btn-success btn-sm">
                            <i class="bi bi-file-excel"></i> Export All
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Client</th>
                                    <th>Mobile</th>
                                    <th>Total</th>
                                    <th>Paid</th>
                                    <th>Balance</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($outstandingClients as $client): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($client['client_name']); ?></td>
                                    <td><?php echo htmlspecialchars($client['mobile_no']); ?></td>
                                    <td><?php echo number_format($client['price'], 2); ?></td>
                                    <td><?php echo number_format($client['payed'], 2); ?></td>
                                    <td><?php echo number_format($client['balance'], 2); ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-primary" data-bs-toggle="modal" 
                                                data-bs-target="#paymentModal" 
                                                data-client-id="<?php echo $client['id']; ?>"
                                                data-client-name="<?php echo htmlspecialchars($client['client_name']); ?>">
                                            <i class="bi bi-cash"></i> Payment
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Recent Payments</h4>
                    <div>
                        <a href="?export=payments" class="btn btn-success btn-sm">
                            <i class="bi bi-file-excel"></i> Export All
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Client</th>
                                    <th>Amount</th>
                                    <th>Recorded By</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentPayments as $payment): ?>
                                <tr>
                                    <td><?php echo date('M j, Y', strtotime($payment['payment_date'])); ?></td>
                                    <td><?php echo htmlspecialchars($payment['client_name']); ?></td>
                                    <td><?php echo number_format($payment['amount'], 2); ?></td>
                                    <td><?php echo htmlspecialchars($payment['recorded_by']); ?></td>
                                    <td>
                                        <form method="post" action="delete.php" class="d-inline">
                                            <input type="hidden" name="payment_id" value="<?php echo $payment['id']; ?>">
                                            <button type="submit" class="btn btn-sm btn-danger" 
                                                    onclick="return confirm('Are you sure you want to delete this payment?\nThis will adjust the client\'s balance.');">
                                                <i class="bi bi-trash"></i> Delete
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Payment Modal -->
<div class="modal fade" id="paymentModal" tabindex="-1" aria-labelledby="paymentModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post">
                <div class="modal-header">
                    <h5 class="modal-title" id="paymentModalLabel">Record Payment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="client_id" id="modalClientId">
                    <div class="mb-3">
                        <label for="clientName" class="form-label">Client</label>
                        <input type="text" class="form-control" id="clientName" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="payment_amount" class="form-label">Payment Amount</label>
                        <input type="number" class="form-control" id="payment_amount" name="payment_amount" 
                               step="0.01" min="0.01" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" name="update_payment" class="btn btn-primary">
                        <i class="bi bi-save"></i> Record Payment
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Initialize payment modal
document.getElementById('paymentModal').addEventListener('show.bs.modal', function (event) {
    var button = event.relatedTarget;
    var modal = this;
    modal.querySelector('#modalClientId').value = button.getAttribute('data-client-id');
    modal.querySelector('#clientName').value = button.getAttribute('data-client-name');
    modal.querySelector('#payment_amount').focus();
});
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>