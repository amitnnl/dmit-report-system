/client_management/
├── config/
│   └── db.php
├── includes/
│   ├── header.php
│   └── footer.php
│   ├── auth.php
│   └── navbar.php
├── assets/
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── script.js
├── clients/
│   ├── add.php
│   ├── edit.php
│   ├── view.php
│   └── delete.php
├── auth/
│   ├── login.php
│   ├── register.php
│   ├── logout.php
│   └── profile.php
├── admin/
│   ├── users.php
│   └── dashboard.php
├── index.php
└── reports.php