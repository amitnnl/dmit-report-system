document.addEventListener('DOMContentLoaded', function() {
    // Enhanced delete confirmation with sweet alert option
    const deleteButtons = document.querySelectorAll('.btn-delete');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const confirmMessage = button.dataset.confirm || 'Are you sure you want to delete this?';
            const isMobile = window.matchMedia('(max-width: 768px)').matches;
            
            if (isMobile && typeof Swal !== 'undefined') {
                // Use SweetAlert if available on mobile
                Swal.fire({
                    title: 'Confirm Delete',
                    text: confirmMessage,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#dc3545',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Delete',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = button.href || 
                            button.closest('form').submit();
                    }
                });
            } else {
                // Fallback to native confirm
                if (confirm(confirmMessage)) {
                    if (button.href) {
                        window.location.href = button.href;
                    } else if (button.closest('form')) {
                        button.closest('form').submit();
                    }
                }
            }
        });
    });
    
    // Enhanced form validation with better UX
    const forms = document.querySelectorAll('form.needs-validation');
    forms.forEach(form => {
        // Add input event listeners for real-time validation
        const inputs = form.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            input.addEventListener('input', function() {
                if (input.checkValidity()) {
                    input.classList.remove('is-invalid');
                    input.classList.add('is-valid');
                } else {
                    input.classList.remove('is-valid');
                }
            });
            
            // Handle blur for better mobile UX
            input.addEventListener('blur', function() {
                input.checkValidity();
            });
        });
        
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
                
                // Scroll to first invalid field on mobile
                if (window.matchMedia('(max-width: 768px)').matches) {
                    const firstInvalid = form.querySelector(':invalid');
                    if (firstInvalid) {
                        firstInvalid.scrollIntoView({
                            behavior: 'smooth',
                            block: 'center'
                        });
                        
                        // Add focus for better mobile UX
                        setTimeout(() => {
                            firstInvalid.focus();
                        }, 300);
                    }
                }
            }
            
            form.classList.add('was-validated');
        }, false);
    });
    
    // Improved phone number formatting with international support
    const phoneInputs = document.querySelectorAll('input[type="tel"]');
    phoneInputs.forEach(input => {
        input.addEventListener('input', function(e) {
            const countryCode = input.dataset.countryCode || '1';
            const value = e.target.value.replace(/\D/g, '');
            
            // Format based on country code (US/Canada by default)
            if (countryCode === '1') {
                const match = value.match(/^(\d{0,3})(\d{0,3})(\d{0,4})$/);
                e.target.value = !match[2] ? match[1] : 
                    `(${match[1]}) ${match[2]}${match[3] ? `-${match[3]}` : ''}`;
            }
            // Add more country formats here as needed
        });
        
        // Better mobile UX
        if ('virtualKeyboard' in navigator) {
            input.setAttribute('inputmode', 'tel');
        }
    });
    
    // Enhanced tooltips with mobile detection
    const initTooltips = function() {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            // Disable tooltips on mobile touch devices
            if ('ontouchstart' in window || navigator.maxTouchPoints) {
                tooltipTriggerEl.setAttribute('title', tooltipTriggerEl.dataset.originalTitle || tooltipTriggerEl.title);
                return;
            }
            
            return new bootstrap.Tooltip(tooltipTriggerEl, {
                boundary: 'window',
                trigger: 'hover focus'
            });
        });
    };
    
    // Initialize tooltips after a slight delay for better mobile detection
    setTimeout(initTooltips, 300);
    
    // Add responsive class to body for mobile detection in CSS
    function handleResponsiveClasses() {
        const body = document.body;
        body.classList.toggle('is-mobile', window.matchMedia('(max-width: 768px)').matches);
        body.classList.toggle('is-desktop', !window.matchMedia('(max-width: 768px)').matches);
    }
    
    // Run on load and resize
    handleResponsiveClasses();
    window.addEventListener('resize', handleResponsiveClasses);
    
    // Add touch detection class
    document.body.classList.add(
        'ontouchstart' in window || navigator.maxTouchPoints ? 'is-touch' : 'no-touch'
    );
});