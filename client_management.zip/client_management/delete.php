<?php
require_once __DIR__ . '../config/db.php';
require_once __DIR__ . '../includes/auth.php';

redirectIfNotLoggedIn();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['payment_id'])) {
    $paymentId = $_POST['payment_id'];
    
    try {
        $pdo->beginTransaction();
        
        // 1. Get payment details first
        $stmt = $pdo->prepare("SELECT client_id, amount FROM payments WHERE id = ?");
        $stmt->execute([$paymentId]);
        $payment = $stmt->fetch();
        
        if ($payment) {
            // 2. Update client's balance by subtracting this payment
            $stmt = $pdo->prepare("UPDATE clients SET 
                payed = payed - ?, 
                balance = balance + ? 
                WHERE id = ?");
            $stmt->execute([$payment['amount'], $payment['amount'], $payment['client_id']]);
            
            // 3. Delete the payment record
            $stmt = $pdo->prepare("DELETE FROM payments WHERE id = ?");
            $stmt->execute([$paymentId]);
            
            $pdo->commit();
            $_SESSION['success'] = "Payment deleted successfully. Client balance adjusted.";
        } else {
            $_SESSION['error'] = "Payment not found";
        }
    } catch (PDOException $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Failed to delete payment: " . $e->getMessage();
    }
}

header("Location: " . APP_URL . "/reports.php");
exit();
?>