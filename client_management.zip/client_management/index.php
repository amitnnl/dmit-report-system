<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/auth.php';

include __DIR__ . '/includes/header.php';
?>

<div class="row">
    <div class="col-md-8 mx-auto">
        <div class="jumbotron text-center">
            <h1 class="display-4">Welcome to Client Management System</h1>
            <p class="lead">Efficiently manage your clients and their information in one place.</p>
            <hr class="my-4">
            
            <?php if (isLoggedIn()): ?>
            <p>Welcome back, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</p>
            <div class="mt-4">
                <a href="<?php echo APP_URL; ?>/clients/view.php" class="btn btn-primary btn-lg mr-3">View Clients</a>
                <a href="<?php echo APP_URL; ?>/clients/add.php" class="btn btn-success btn-lg">Add New Client</a>
            </div>
            <?php else: ?>
            <p>Please login or register to access the system.</p>
            <div class="mt-4">
                <a href="<?php echo APP_URL; ?>/auth/login.php" class="btn btn-primary btn-lg mr-3">Login</a>
                <a href="<?php echo APP_URL; ?>/auth/register.php" class="btn btn-secondary btn-lg">Register</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>